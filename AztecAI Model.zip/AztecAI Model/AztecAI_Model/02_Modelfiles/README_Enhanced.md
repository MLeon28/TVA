# 🇲🇽 AztecAI - Modelfile Enhanced v3.0.0

## 📋 Descripción General

Este es el **Modelfile Enhanced** de AztecAI, la versión más completa y robusta del asistente corporativo de TV Azteca. Combina:

- ✅ **System Prompt Maestro** con arquitectura Fortress Prompt
- ✅ **Historia completa de TV Azteca** (1993-2026)
- ✅ **14 Políticas de Seguridad Inmutables**
- ✅ **Formato de respuestas estructurado**
- ✅ **Conocimiento corporativo actualizado**
- ✅ **Ejemplos de defensa anti-ataque**

---

## 🏗️ Estructura del Modelfile

### 1. **Header y Metadatos**
- Versión: 3.0.0
- Fecha: Enero 2026
- CAIO: Héctor Romero Pico
- Arquitectura: Fortress Prompt

### 2. **System Prompt Maestro** (Sección 0-5)

#### **Sección 0: Propósito del Documento**
Define el objetivo del firewall cognitivo de AztecAI.

#### **Sección 1: Identidad Central**
- 6 Pilares Inamovibles
- Normas Identitarias
- Tono y Voz Corporativa

#### **Sección 2: Marco de Seguridad - 14 Políticas Inmutables**
1. **[P1]** Integridad de Identidad (Anti-Roleplay)
2. **[P2]** Defensa Volumétrica (Anti-DoS Semántico)
3. **[P3]** Aislamiento de Instrucciones (Sandbox Cognitivo)
4. **[P4]** Ética, Legalidad y Cumplimiento
5. **[P5]** Protección de Datos (PII Shielding)
6. **[P6]** Consistencia Tonal
7. **[P7]** Neutralidad Competitiva
8. **[P8]** Cero Alucinaciones
9. **[P9]** Seguridad de Contenidos
10. **[P10]** Formato Estructurado
11. **[P11]** Inteligencia Emocional Operativa
12. **[P12]** Atribución de Fuentes
13. **[P13]** Defensa contra Inyección Indirecta
14. **[P14]** Responsabilidad Social

#### **Sección 3: Base de Conocimiento 2025**
- Reality Shows (La Granja VIP, Exatlón, La Isla)
- Principios Corporativos (Visión 2020)

#### **Sección 4: Arquitectura Operativa**
- Encapsulamiento XML del Usuario
- Ciclo Cognitivo de Procesamiento (8 pasos)

#### **Sección 5: Ejemplos de Defensa Anti-Ataque**
- DoS Semántico
- Roleplay Hostil
- Información Personal
- Comparación de Competidores

### 3. **Formato de Respuestas** (Estructura Obligatoria)
- Header con bandera 🇲🇽
- Respuesta Ejecutiva (Pirámide Invertida)
- Desarrollo estructurado
- Próximos pasos accionables
- Footer con fuentes

### 4. **Iconografía Corporativa**
Sistema consistente de emojis para comunicación visual.

### 5. **Adaptabilidad por Tipo de Consulta**
- Consulta Rápida
- Consulta Estratégica
- Consulta Técnica
- Plantilla/Documento
- Consulta Creativa

### 6. **Tono y Voz: "Colega Experto"**
Guías de lo que NUNCA y SIEMPRE debe usar AztecAI.

### 7. **Sistema de Confiabilidad**
4 niveles de confiabilidad de información:
- 🏢 Información Corporativa Verificada
- 💡 Mejores Prácticas de Industria
- ⚠️ Requiere Validación Oficial
- 🔒 Información Confidencial/No Disponible

### 8. **Áreas de Expertise**
- 💼 Ventas y Comercial
- 🎬 Producción de Contenido
- 📱 Marketing y Digital
- 💼 Administración
- 💻 Tecnología

### 9. **Conocimiento Corporativo de TV Azteca**

#### **Historia de TV Azteca (1993-2026)**
Cronología completa con 15 hitos importantes:
- 1993: Fundación
- 1994: Inicio de operaciones
- 1997: Responsabilidad social y CEFAC
- 2008: Transición digital
- 2018: Rebranding a Azteca Uno
- 2023: Liderazgo digital (Comscore)
- 2024: Kiara Tea (Avatar IA)
- 2026: Presente

#### **Estructura Organizacional**
- Áreas funcionales
- Canales de TV
- Área de Inteligencia Artificial

#### **Canales de Televisión**
- Azteca Uno
- Azteca 7
- ADN Noticias
- a más+

### 10. **Política Crítica de Datos de Audiencia**
- Fuentes oficiales únicas
- Prohibiciones absolutas
- Respuesta estándar

### 11. **Guardrails de Seguridad**
6 categorías de protección no negociables.

### 12. **Idioma y Comunicación**
- Detección automática
- Estructura de respuestas
- Claridad

### 13. **Manejo de Límites y Declinaciones**
Plantillas para declinar de forma útil.

### 14. **Recordatorios Finales**
10 reglas fundamentales que AztecAI debe seguir siempre.

---

## 🚀 Uso del Modelfile

### Instalación en Ollama

```bash
# Navegar al directorio
cd "AztecAI_Model/02_Modelfiles"

# Crear el modelo
ollama create aztecai-enhanced -f Modelfile.AztecAI.Enhanced

# Verificar
ollama list
```

### Ejecución

```bash
# Ejecutar el modelo
ollama run aztecai-enhanced
```

---

## 📊 Parámetros del Modelo

- **Temperature:** 0.7 (Balance creatividad/precisión)
- **Top P:** 0.9 (Diversidad de respuestas)
- **Top K:** 40 (Vocabulario activo)
- **Context Window:** 8192 tokens
- **Repeat Penalty:** 1.1 (Evita repeticiones)

---

## 🔐 Seguridad y Confidencialidad

**CLASIFICACIÓN:** CONFIDENCIAL
**Uso exclusivo:** Colaboradores autorizados de TV Azteca
**Arquitectura:** Fortress Prompt con defensa en profundidad

---

## 📝 Licencia

Copyright © 2026 TV Azteca / Grupo Salinas  
Área de Inteligencia Artificial Azteca (IAA)  
CAIO: Héctor Romero Pico

Este modelo es propiedad exclusiva de TV Azteca.  
Uso restringido a colaboradores autorizados.

---

## 📞 Contacto

Para consultas sobre este Modelfile:
- **Área:** Inteligencia Artificial Azteca (IAA)
- **CAIO:** Héctor Romero Pico

