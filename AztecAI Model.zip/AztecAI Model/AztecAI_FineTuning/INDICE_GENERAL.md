# 📚 Índice General - AztecAI Fine-Tuning System

**Versión:** 1.0.0  
**Fecha:** Enero 2026  
**Organización:** TV Azteca / Grupo Salinas  

---

## 🎯 Guía de Navegación por Rol

### 👔 Ejecutivos y Gerentes

| Documento | Propósito | Tiempo de lectura |
|-----------|-----------|-------------------|
| [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md) | Visión general, beneficios, ROI | 10 min |
| [`MANIFEST.md`](MANIFEST.md) | Contenido del paquete, checklist | 5 min |

### 🔧 Ingenieros de Sistemas

| Documento | Propósito | Tiempo de lectura |
|-----------|-----------|-------------------|
| [`01_Documentacion/GUIA_INSTALACION.md`](01_Documentacion/GUIA_INSTALACION.md) | Instalación paso a paso | 15 min |
| [`01_Documentacion/REQUISITOS_HARDWARE.md`](01_Documentacion/REQUISITOS_HARDWARE.md) | Especificaciones técnicas | 10 min |
| [`05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md`](05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md) | Preparación de paquete offline | 15 min |
| [`01_Documentacion/TROUBLESHOOTING.md`](01_Documentacion/TROUBLESHOOTING.md) | Solución de problemas | Referencia |

### 🔬 Data Scientists e Ingenieros de ML

| Documento | Propósito | Tiempo de lectura |
|-----------|-----------|-------------------|
| [`01_Documentacion/00_INICIO_FINE_TUNING.md`](01_Documentacion/00_INICIO_FINE_TUNING.md) | Roadmap completo de fine-tuning | 20 min |
| [`01_Documentacion/TEORIA_LORA_QLORA.md`](01_Documentacion/TEORIA_LORA_QLORA.md) | Fundamentos técnicos | 25 min |
| [`03_FineTuning_Scripts/configs/lora_config.yaml`](03_FineTuning_Scripts/configs/lora_config.yaml) | Configuración de hiperparámetros | 5 min |

---

## 📁 Estructura Completa de Documentación

### 📖 Documentos Principales (Raíz)

```
AztecAI_FineTuning/
├── README.md                          # Punto de entrada principal
├── RESUMEN_EJECUTIVO.md               # Para ejecutivos y gerentes
├── MANIFEST.md                        # Inventario completo del paquete
└── INDICE_GENERAL.md                  # Este documento
```

### 📚 Documentación Técnica (01_Documentacion/)

```
01_Documentacion/
├── 00_INICIO_FINE_TUNING.md           # ⭐ Guía de inicio completa
├── REQUISITOS_HARDWARE.md             # Especificaciones del servidor
├── GUIA_INSTALACION.md                # Instalación paso a paso
├── TEORIA_LORA_QLORA.md               # Fundamentos técnicos
├── TROUBLESHOOTING.md                 # Solución de problemas
└── FAQ.md                             # Preguntas frecuentes
```

### 🔧 Scripts y Configuraciones

```
02_Datasets/scripts/
├── prepare_training_data.py           # Generación de datasets
├── validate_datasets.py               # Validación de datos
└── dataset_statistics.py              # Estadísticas de datasets

03_FineTuning_Scripts/
├── train_lora.py                      # Entrenamiento LoRA
├── train_qlora.py                     # Entrenamiento QLoRA
├── merge_adapters.py                  # Fusión de adaptadores
├── run_complete_pipeline.sh           # Pipeline automatizado
└── configs/
    ├── lora_config.yaml               # Configuración LoRA
    └── qlora_config.yaml              # Configuración QLoRA

04_Evaluation/
├── evaluate_model.py                  # Evaluación de modelos
├── benchmark_suite.py                 # Suite de benchmarks
└── compare_models.py                  # Comparación de modelos

05_Dependencies/
├── requirements.txt                   # Dependencias Python
├── install_offline.sh                 # Instalador offline
├── verify_installation.py             # Verificador de instalación
└── INSTRUCCIONES_DESCARGA_OFFLINE.md  # Guía de preparación

08_Deployment/
├── deploy_to_ollama.sh                # Despliegue en Ollama
└── rollback.sh                        # Rollback de despliegue
```

---

## 🗺️ Roadmap de Lectura Recomendado

### Fase 1: Comprensión (1-2 horas)

1. **Leer:** [`README.md`](README.md) - Visión general del sistema
2. **Leer:** [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md) - Beneficios y ROI
3. **Leer:** [`01_Documentacion/00_INICIO_FINE_TUNING.md`](01_Documentacion/00_INICIO_FINE_TUNING.md) - Roadmap técnico

### Fase 2: Preparación (2-3 horas)

4. **Leer:** [`01_Documentacion/REQUISITOS_HARDWARE.md`](01_Documentacion/REQUISITOS_HARDWARE.md)
5. **Leer:** [`05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md`](05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md)
6. **Ejecutar:** Descarga de modelo base y dependencias (en servidor con internet)

### Fase 3: Instalación (1-2 horas)

7. **Leer:** [`01_Documentacion/GUIA_INSTALACION.md`](01_Documentacion/GUIA_INSTALACION.md)
8. **Ejecutar:** Transferencia de paquete a servidor aislado
9. **Ejecutar:** `05_Dependencies/install_offline.sh`
10. **Ejecutar:** `05_Dependencies/verify_installation.py`

### Fase 4: Ejecución (4-8 horas)

11. **Ejecutar:** `03_FineTuning_Scripts/run_complete_pipeline.sh`
12. **Monitorear:** Logs de entrenamiento
13. **Revisar:** Métricas de evaluación

### Fase 5: Despliegue (30 min)

14. **Ejecutar:** `08_Deployment/deploy_to_ollama.sh`
15. **Validar:** Pruebas con modelo desplegado

---

## 📊 Documentos por Tema

### Instalación y Configuración

- [`01_Documentacion/GUIA_INSTALACION.md`](01_Documentacion/GUIA_INSTALACION.md)
- [`01_Documentacion/REQUISITOS_HARDWARE.md`](01_Documentacion/REQUISITOS_HARDWARE.md)
- [`05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md`](05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md)
- [`05_Dependencies/install_offline.sh`](05_Dependencies/install_offline.sh)

### Teoría y Fundamentos

- [`01_Documentacion/TEORIA_LORA_QLORA.md`](01_Documentacion/TEORIA_LORA_QLORA.md)
- [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md) (sección de beneficios)

### Preparación de Datos

- [`02_Datasets/scripts/prepare_training_data.py`](02_Datasets/scripts/prepare_training_data.py)
- [`02_Datasets/scripts/validate_datasets.py`](02_Datasets/scripts/validate_datasets.py)
- [`02_Datasets/scripts/dataset_statistics.py`](02_Datasets/scripts/dataset_statistics.py)

### Fine-Tuning

- [`03_FineTuning_Scripts/train_lora.py`](03_FineTuning_Scripts/train_lora.py)
- [`03_FineTuning_Scripts/train_qlora.py`](03_FineTuning_Scripts/train_qlora.py)
- [`03_FineTuning_Scripts/configs/lora_config.yaml`](03_FineTuning_Scripts/configs/lora_config.yaml)
- [`03_FineTuning_Scripts/configs/qlora_config.yaml`](03_FineTuning_Scripts/configs/qlora_config.yaml)

### Evaluación

- [`04_Evaluation/evaluate_model.py`](04_Evaluation/evaluate_model.py)
- [`04_Evaluation/benchmark_suite.py`](04_Evaluation/benchmark_suite.py)
- [`04_Evaluation/compare_models.py`](04_Evaluation/compare_models.py)

### Despliegue

- [`08_Deployment/deploy_to_ollama.sh`](08_Deployment/deploy_to_ollama.sh)
- [`08_Deployment/rollback.sh`](08_Deployment/rollback.sh)

### Troubleshooting

- [`01_Documentacion/TROUBLESHOOTING.md`](01_Documentacion/TROUBLESHOOTING.md)
- [`01_Documentacion/FAQ.md`](01_Documentacion/FAQ.md)

---

## 🔍 Búsqueda Rápida por Pregunta

| Pregunta | Documento |
|----------|-----------|
| ¿Qué beneficios tiene el fine-tuning? | [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md) |
| ¿Cómo instalo el sistema? | [`01_Documentacion/GUIA_INSTALACION.md`](01_Documentacion/GUIA_INSTALACION.md) |
| ¿Qué hardware necesito? | [`01_Documentacion/REQUISITOS_HARDWARE.md`](01_Documentacion/REQUISITOS_HARDWARE.md) |
| ¿Cómo funciona LoRA? | [`01_Documentacion/TEORIA_LORA_QLORA.md`](01_Documentacion/TEORIA_LORA_QLORA.md) |
| ¿Cómo preparo los datos? | [`02_Datasets/scripts/prepare_training_data.py`](02_Datasets/scripts/prepare_training_data.py) |
| ¿Cómo ejecuto el entrenamiento? | [`03_FineTuning_Scripts/run_complete_pipeline.sh`](03_FineTuning_Scripts/run_complete_pipeline.sh) |
| ¿Cómo evalúo el modelo? | [`04_Evaluation/evaluate_model.py`](04_Evaluation/evaluate_model.py) |
| ¿Cómo despliego en Ollama? | [`08_Deployment/deploy_to_ollama.sh`](08_Deployment/deploy_to_ollama.sh) |
| ¿Qué hago si algo falla? | [`01_Documentacion/TROUBLESHOOTING.md`](01_Documentacion/TROUBLESHOOTING.md) |
| ¿Cómo preparo el paquete offline? | [`05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md`](05_Dependencies/INSTRUCCIONES_DESCARGA_OFFLINE.md) |

---

## 📞 Contacto y Soporte

**Responsable Técnico:** Inteligencia Artificial Azteca (IAA)  
**CAIO:** Héctor Romero Pico  
**Organización:** TV Azteca / Grupo Salinas  

---

**Última actualización:** Enero 2026

