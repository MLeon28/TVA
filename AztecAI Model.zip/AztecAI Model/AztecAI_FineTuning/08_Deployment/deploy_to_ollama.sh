#!/bin/bash
################################################################################
# Script de Despliegue de Modelo Fine-Tuneado en Ollama
# 
# Autor: Inteligencia Artificial Azteca (IAA)
# Versión: 1.0.0
# Fecha: Enero 2026
#
# Descripción:
#   Despliega el modelo fine-tuneado en Ollama para uso en producción
#
# Uso:
#   bash deploy_to_ollama.sh
################################################################################

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuración
MODEL_NAME="aztecai-finetuned"
MERGED_MODEL_PATH="../06_Models/merged_models/aztecai_merged"
MODELFILE_PATH="./Modelfile.AztecAI.FineTuned"
BACKUP_DIR="./backups"

################################################################################
# Funciones
################################################################################

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

################################################################################
# Verificaciones
################################################################################

check_ollama() {
    print_header "Verificando Ollama"
    
    if ! command -v ollama &> /dev/null; then
        print_error "Ollama no está instalado"
        exit 1
    fi
    
    print_success "Ollama instalado"
    
    if ! systemctl is-active --quiet ollama; then
        print_warning "Servicio Ollama no está activo, iniciando..."
        systemctl start ollama
        sleep 2
    fi
    
    print_success "Servicio Ollama activo"
}

check_merged_model() {
    print_header "Verificando Modelo Fusionado"
    
    if [ ! -d "$MERGED_MODEL_PATH" ]; then
        print_error "Modelo fusionado no encontrado en: $MERGED_MODEL_PATH"
        print_info "Ejecuta primero: python3 ../03_FineTuning_Scripts/merge_adapters.py"
        exit 1
    fi
    
    print_success "Modelo fusionado encontrado"
}

################################################################################
# Backup del Modelo Actual
################################################################################

backup_current_model() {
    print_header "Backup del Modelo Actual"
    
    # Verificar si existe el modelo actual
    if ollama list | grep -q "$MODEL_NAME"; then
        print_info "Modelo actual encontrado, creando backup..."
        
        mkdir -p "$BACKUP_DIR"
        TIMESTAMP=$(date +%Y%m%d_%H%M%S)
        BACKUP_NAME="${MODEL_NAME}_backup_${TIMESTAMP}"
        
        # Copiar modelo actual
        ollama cp "$MODEL_NAME" "$BACKUP_NAME"
        
        print_success "Backup creado: $BACKUP_NAME"
        
        # Guardar información del backup
        echo "$BACKUP_NAME" > "$BACKUP_DIR/latest_backup.txt"
        echo "Fecha: $(date)" >> "$BACKUP_DIR/latest_backup.txt"
    else
        print_info "No hay modelo actual para hacer backup"
    fi
}

################################################################################
# Conversión de Modelo HuggingFace a GGUF
################################################################################

convert_to_gguf() {
    print_header "Convirtiendo Modelo a Formato GGUF"
    
    print_info "Este paso requiere llama.cpp para conversión..."
    
    # Verificar si existe el script de conversión
    CONVERT_SCRIPT="./convert_hf_to_gguf.py"
    
    if [ ! -f "$CONVERT_SCRIPT" ]; then
        print_warning "Script de conversión no encontrado"
        print_info "Usando modelo HuggingFace directamente (requiere Ollama con soporte HF)"
    else
        print_info "Convirtiendo modelo a GGUF..."
        python3 "$CONVERT_SCRIPT" \
            --model "$MERGED_MODEL_PATH" \
            --output "../06_Models/merged_models/aztecai_merged.gguf"
        
        print_success "Modelo convertido a GGUF"
    fi
}

################################################################################
# Creación de Modelfile
################################################################################

create_modelfile() {
    print_header "Creando Modelfile"
    
    cat > "$MODELFILE_PATH" << 'EOF'
# Modelfile para AztecAI Fine-Tuneado
# Versión: 1.0.0 (Fine-Tuned)
# Fecha: Enero 2026

FROM ../06_Models/merged_models/aztecai_merged.gguf

# System Prompt Reducido (el conocimiento ya está en el modelo)
SYSTEM """
Eres AztecAI, el asistente corporativo de TV Azteca.

Estructura tus respuestas con:
1. Header: 🇲🇽 AztecAI
2. Respuesta ejecutiva (⚡)
3. Desarrollo (si aplica)
4. Próximos pasos (🎯)
5. Footer con fuentes

Mantén un tono profesional, claro y orientado a la acción.
"""

# Parámetros optimizados para modelo fine-tuneado
PARAMETER temperature 0.7
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER num_ctx 8192
PARAMETER num_predict 2048
PARAMETER repeat_penalty 1.1
PARAMETER seed -1

# Mensajes de template
TEMPLATE """{{ if .System }}<|system|>
{{ .System }}<|end|>
{{ end }}{{ if .Prompt }}<|user|>
{{ .Prompt }}<|end|>
{{ end }}<|assistant|>
{{ .Response }}<|end|>
"""
EOF
    
    print_success "Modelfile creado: $MODELFILE_PATH"
}

################################################################################
# Registro en Ollama
################################################################################

register_in_ollama() {
    print_header "Registrando Modelo en Ollama"
    
    print_info "Creando modelo en Ollama..."
    
    # Eliminar modelo anterior si existe
    if ollama list | grep -q "$MODEL_NAME"; then
        print_warning "Eliminando versión anterior..."
        ollama rm "$MODEL_NAME"
    fi
    
    # Crear nuevo modelo
    ollama create "$MODEL_NAME" -f "$MODELFILE_PATH"
    
    print_success "Modelo registrado en Ollama: $MODEL_NAME"
}

################################################################################
# Validación
################################################################################

validate_deployment() {
    print_header "Validando Despliegue"
    
    # Verificar que el modelo esté listado
    if ollama list | grep -q "$MODEL_NAME"; then
        print_success "Modelo encontrado en Ollama"
    else
        print_error "Modelo no encontrado en Ollama"
        exit 1
    fi
    
    # Test básico
    print_info "Ejecutando test básico..."
    
    TEST_RESPONSE=$(ollama run "$MODEL_NAME" "¿Qué es TV Azteca?" --verbose=false 2>/dev/null | head -20)
    
    if [ -n "$TEST_RESPONSE" ]; then
        print_success "Modelo responde correctamente"
        echo ""
        echo "Respuesta de prueba:"
        echo "---"
        echo "$TEST_RESPONSE"
        echo "---"
    else
        print_error "Modelo no genera respuestas"
        exit 1
    fi
}

################################################################################
# Información Final
################################################################################

print_final_info() {
    print_header "Despliegue Completado"
    
    echo -e "${GREEN}✅ Modelo fine-tuneado desplegado exitosamente${NC}\n"
    
    echo "📋 Información del modelo:"
    echo "   Nombre: $MODEL_NAME"
    echo "   Ruta: $MERGED_MODEL_PATH"
    echo ""
    
    echo "🚀 Uso del modelo:"
    echo "   CLI:    ollama run $MODEL_NAME"
    echo "   API:    curl http://localhost:11434/api/generate -d '{\"model\":\"$MODEL_NAME\",\"prompt\":\"Hola\"}'"
    echo "   WebUI:  Seleccionar '$MODEL_NAME' en OpenWebUI"
    echo ""
    
    echo "🔄 Rollback (si es necesario):"
    if [ -f "$BACKUP_DIR/latest_backup.txt" ]; then
        BACKUP_NAME=$(head -1 "$BACKUP_DIR/latest_backup.txt")
        echo "   bash rollback.sh $BACKUP_NAME"
    else
        echo "   No hay backup disponible"
    fi
    echo ""
}

################################################################################
# Main
################################################################################

main() {
    print_header "🇲🇽 AztecAI - Despliegue de Modelo Fine-Tuneado"
    
    # Verificaciones
    check_ollama
    check_merged_model
    
    # Backup
    backup_current_model
    
    # Conversión (si es necesario)
    # convert_to_gguf
    
    # Despliegue
    create_modelfile
    register_in_ollama
    
    # Validación
    validate_deployment
    
    # Info final
    print_final_info
}

main "$@"

