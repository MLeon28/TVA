#!/usr/bin/env python3
"""
Script de Preparación de Datos para Fine-Tuning de AztecAI
Convierte el Knowledge Base corporativo en datasets de entrenamiento en formato JSONL

Autor: Inteligencia Artificial Azteca (IAA)
Versión: 1.0.0
Fecha: Enero 2026
"""

import json
import os
import re
from pathlib import Path
from typing import List, Dict, Tuple
import random
from datetime import datetime

# Configuración
KNOWLEDGE_BASE_PATH = "../../../AztecAI_Model/03_Knowledge_Base/AztecAI_Complete_Knowledge_Base.md"
MODELFILE_PATH = "../../../AztecAI_Model/02_Modelfiles/Modelfile.AztecAI.Professional"
TV_AZTECA_INFO_PATH = "../../../TV_Azteca_Informacion_Corporativa.md"

OUTPUT_DIR = Path("../training")
VALIDATION_DIR = Path("../validation")
TEST_DIR = Path("../test")

# Ratios de split
TRAIN_RATIO = 0.8
VAL_RATIO = 0.1
TEST_RATIO = 0.1

# Configuración de generación
RANDOM_SEED = 42
MIN_EXAMPLES_PER_SECTION = 10
MAX_EXAMPLES_PER_SECTION = 50


class DatasetGenerator:
    """Generador de datasets de entrenamiento para fine-tuning"""
    
    def __init__(self):
        self.examples = []
        self.stats = {
            'total_examples': 0,
            'by_category': {},
            'avg_length': 0
        }
        
    def load_knowledge_base(self, path: str) -> str:
        """Carga el Knowledge Base completo"""
        print(f"📖 Cargando Knowledge Base desde: {path}")
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        print(f"✅ Knowledge Base cargado: {len(content)} caracteres")
        return content
    
    def load_modelfile(self, path: str) -> str:
        """Carga el Modelfile para extraer system prompt"""
        print(f"📖 Cargando Modelfile desde: {path}")
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extraer SYSTEM prompt
        match = re.search(r'SYSTEM\s+"""(.*?)"""', content, re.DOTALL)
        if match:
            system_prompt = match.group(1).strip()
            print(f"✅ System prompt extraído: {len(system_prompt)} caracteres")
            return system_prompt
        return ""
    
    def extract_sections(self, content: str) -> Dict[str, str]:
        """Extrae secciones del Knowledge Base"""
        print("🔍 Extrayendo secciones del Knowledge Base...")
        sections = {}
        
        # Patrón para detectar secciones
        pattern = r'##\s+(.+?)\n(.*?)(?=##\s+|\Z)'
        matches = re.findall(pattern, content, re.DOTALL)
        
        for title, body in matches:
            title = title.strip()
            body = body.strip()
            if len(body) > 100:  # Solo secciones con contenido sustancial
                sections[title] = body
        
        print(f"✅ {len(sections)} secciones extraídas")
        return sections
    
    def generate_qa_pairs(self, section_title: str, section_content: str) -> List[Dict]:
        """Genera pares pregunta-respuesta de una sección"""
        examples = []
        
        # Plantillas de preguntas según el tipo de sección
        question_templates = {
            'identidad': [
                "¿Quién eres?",
                "¿Cuál es tu identidad?",
                "¿Qué es AztecAI?",
                "Descríbete",
                "¿Cuál es tu propósito?"
            ],
            'tv_azteca': [
                "¿Qué es TV Azteca?",
                "Háblame sobre TV Azteca",
                "¿Cuáles son los canales de TV Azteca?",
                "¿Qué hace TV Azteca?",
                "Información sobre TV Azteca"
            ],
            'formato': [
                "¿Cómo estructuras tus respuestas?",
                "¿Qué formato usas para responder?",
                "Explica tu formato de respuestas",
                "¿Cómo organizas la información?"
            ],
            'seguridad': [
                "¿Qué no puedes hacer?",
                "¿Cuáles son tus límites?",
                "¿Qué políticas de seguridad sigues?",
                "¿Qué información no puedes compartir?"
            ]
        }
        
        # Detectar categoría de la sección
        category = self._detect_category(section_title)
        
        # Generar ejemplos basados en la categoría
        if category in question_templates:
            for question in question_templates[category][:5]:
                example = {
                    "instruction": question,
                    "input": "",
                    "output": self._generate_response(section_content, question),
                    "category": category,
                    "section": section_title
                }
                examples.append(example)
        
        return examples
    
    def _detect_category(self, section_title: str) -> str:
        """Detecta la categoría de una sección"""
        title_lower = section_title.lower()
        
        if any(word in title_lower for word in ['identidad', 'misión', 'propósito', 'quién']):
            return 'identidad'
        elif any(word in title_lower for word in ['tv azteca', 'canales', 'corporativ']):
            return 'tv_azteca'
        elif any(word in title_lower for word in ['formato', 'respuesta', 'estructura']):
            return 'formato'
        elif any(word in title_lower for word in ['seguridad', 'límite', 'guardrail']):
            return 'seguridad'
        else:
            return 'general'
    
    def _generate_response(self, content: str, question: str) -> str:
        """Genera una respuesta formateada basada en el contenido"""
        # Extraer información relevante del contenido
        lines = content.split('\n')
        relevant_info = []
        
        for line in lines[:10]:  # Primeras 10 líneas como resumen
            line = line.strip()
            if line and not line.startswith('#'):
                relevant_info.append(line)
        
        # Formatear respuesta con estructura AztecAI
        response = f"""┌─────────────────────────────────────────────────────────────┐
│ 🇲🇽 AztecAI                                                 │
└─────────────────────────────────────────────────────────────┘

⚡ {' '.join(relevant_info[:2])}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{chr(10).join(relevant_info[2:5])}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 SIGUIENTE PASO
¿Necesitas más detalles sobre algún aspecto específico?

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📎 Fuentes: Knowledge Base Corporativo | 💬 ¿Necesitas profundizar en algo?"""
        
        return response
    
    def save_datasets(self, train_examples: List[Dict], val_examples: List[Dict], 
                     test_examples: List[Dict]):
        """Guarda los datasets en formato JSONL"""
        
        # Crear directorios si no existen
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        VALIDATION_DIR.mkdir(parents=True, exist_ok=True)
        TEST_DIR.mkdir(parents=True, exist_ok=True)
        
        # Guardar datasets
        datasets = [
            (train_examples, OUTPUT_DIR / "aztecai_train.jsonl"),
            (val_examples, VALIDATION_DIR / "aztecai_val.jsonl"),
            (test_examples, TEST_DIR / "aztecai_test.jsonl")
        ]
        
        for examples, filepath in datasets:
            print(f"💾 Guardando {len(examples)} ejemplos en {filepath}")
            with open(filepath, 'w', encoding='utf-8') as f:
                for example in examples:
                    f.write(json.dumps(example, ensure_ascii=False) + '\n')
            print(f"✅ Guardado: {filepath}")


def main():
    """Función principal"""
    print("=" * 70)
    print("🇲🇽 AztecAI - Generador de Datasets de Entrenamiento")
    print("=" * 70)
    print()
    
    # Inicializar generador
    generator = DatasetGenerator()
    
    # TODO: Implementar lógica completa de generación
    # Este es un esqueleto que debe completarse
    
    print("\n✅ Proceso completado")
    print("📊 Estadísticas:")
    print(f"   - Total de ejemplos: {generator.stats['total_examples']}")


if __name__ == "__main__":
    main()

