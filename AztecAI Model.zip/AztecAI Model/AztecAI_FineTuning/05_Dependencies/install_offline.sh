#!/bin/bash
################################################################################
# Script de Instalación Offline de Dependencias para AztecAI Fine-Tuning
# 
# Autor: Inteligencia Artificial Azteca (IAA)
# Versión: 1.0.0
# Fecha: Enero 2026
#
# Descripción:
#   Instala todas las dependencias necesarias para fine-tuning de AztecAI
#   en un entorno completamente offline (sin acceso a internet)
#
# Uso:
#   sudo bash install_offline.sh
################################################################################

set -e  # Exit on error

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

################################################################################
# Funciones de Utilidad
################################################################################

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "Este script debe ejecutarse como root (sudo)"
        exit 1
    fi
    print_success "Ejecutando como root"
}

################################################################################
# Verificaciones Pre-Instalación
################################################################################

check_prerequisites() {
    print_header "Verificando Prerrequisitos"
    
    # Verificar Ubuntu
    if ! grep -q "Ubuntu" /etc/os-release; then
        print_warning "Este script está optimizado para Ubuntu 22.04"
    else
        print_success "Sistema operativo: Ubuntu"
    fi
    
    # Verificar Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 no está instalado"
        exit 1
    fi
    
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    print_success "Python instalado: $PYTHON_VERSION"
    
    # Verificar pip
    if ! command -v pip3 &> /dev/null; then
        print_warning "pip3 no está instalado, instalando..."
        apt-get update
        apt-get install -y python3-pip
    fi
    print_success "pip3 instalado"
    
    # Verificar espacio en disco
    AVAILABLE_SPACE=$(df -BG /opt | tail -1 | awk '{print $4}' | sed 's/G//')
    if [ "$AVAILABLE_SPACE" -lt 50 ]; then
        print_warning "Espacio disponible bajo: ${AVAILABLE_SPACE}GB (recomendado: 50GB+)"
    else
        print_success "Espacio disponible: ${AVAILABLE_SPACE}GB"
    fi
}

################################################################################
# Instalación de Dependencias del Sistema
################################################################################

install_system_dependencies() {
    print_header "Instalando Dependencias del Sistema"
    
    print_info "Actualizando lista de paquetes..."
    apt-get update -qq
    
    print_info "Instalando paquetes del sistema..."
    apt-get install -y \
        build-essential \
        python3-dev \
        python3-pip \
        git \
        curl \
        wget \
        vim \
        htop \
        tmux \
        unzip \
        libssl-dev \
        libffi-dev \
        libbz2-dev \
        libreadline-dev \
        libsqlite3-dev \
        libncurses5-dev \
        libncursesw5-dev \
        xz-utils \
        tk-dev \
        libxml2-dev \
        libxmlsec1-dev \
        liblzma-dev
    
    print_success "Dependencias del sistema instaladas"
}

################################################################################
# Instalación de Dependencias Python (Offline)
################################################################################

install_python_dependencies() {
    print_header "Instalando Dependencias Python (Offline)"
    
    WHEELS_DIR="./python_packages"
    
    # Verificar que exista el directorio de wheels
    if [ ! -d "$WHEELS_DIR" ]; then
        print_error "Directorio de wheels no encontrado: $WHEELS_DIR"
        print_info "Debe descargar las dependencias primero con:"
        print_info "  pip download -r requirements.txt -d python_packages/"
        exit 1
    fi
    
    # Contar wheels disponibles
    WHEEL_COUNT=$(ls -1 "$WHEELS_DIR"/*.whl 2>/dev/null | wc -l)
    if [ "$WHEEL_COUNT" -eq 0 ]; then
        print_error "No se encontraron archivos .whl en $WHEELS_DIR"
        exit 1
    fi
    
    print_info "Encontrados $WHEEL_COUNT paquetes wheel"
    
    # Actualizar pip
    print_info "Actualizando pip..."
    pip3 install --upgrade --no-index --find-links="$WHEELS_DIR" pip
    
    # Instalar dependencias desde wheels locales
    print_info "Instalando dependencias Python desde wheels locales..."
    pip3 install --no-index --find-links="$WHEELS_DIR" -r requirements.txt
    
    print_success "Dependencias Python instaladas"
}

################################################################################
# Verificación de Instalación
################################################################################

verify_installation() {
    print_header "Verificando Instalación"
    
    print_info "Verificando paquetes críticos..."
    
    # Lista de paquetes críticos
    CRITICAL_PACKAGES=(
        "torch"
        "transformers"
        "peft"
        "datasets"
        "accelerate"
        "bitsandbytes"
    )
    
    ALL_OK=true
    
    for package in "${CRITICAL_PACKAGES[@]}"; do
        if python3 -c "import $package" 2>/dev/null; then
            VERSION=$(python3 -c "import $package; print($package.__version__)" 2>/dev/null || echo "unknown")
            print_success "$package ($VERSION)"
        else
            print_error "$package NO INSTALADO"
            ALL_OK=false
        fi
    done
    
    if [ "$ALL_OK" = true ]; then
        print_success "Todas las dependencias críticas están instaladas"
        return 0
    else
        print_error "Algunas dependencias críticas faltan"
        return 1
    fi
}

################################################################################
# Configuración Post-Instalación
################################################################################

post_install_config() {
    print_header "Configuración Post-Instalación"
    
    # Crear directorios necesarios
    print_info "Creando estructura de directorios..."
    mkdir -p ../06_Models/{lora_adapters,checkpoints,logs,merged_models}
    mkdir -p ../02_Datasets/{training,validation,test}
    mkdir -p ../04_Evaluation/metrics
    
    print_success "Directorios creados"
    
    # Configurar permisos
    print_info "Configurando permisos..."
    chmod +x ../03_FineTuning_Scripts/*.py
    chmod +x ../02_Datasets/scripts/*.py
    chmod +x ../04_Evaluation/*.py
    chmod +x ../08_Deployment/*.sh
    
    print_success "Permisos configurados"
}

################################################################################
# Información Final
################################################################################

print_final_info() {
    print_header "Instalación Completada"
    
    echo -e "${GREEN}✅ Todas las dependencias han sido instaladas exitosamente${NC}\n"
    
    echo "📋 Próximos pasos:"
    echo "   1. Preparar datasets de entrenamiento:"
    echo "      cd ../02_Datasets/scripts"
    echo "      python3 prepare_training_data.py"
    echo ""
    echo "   2. Ejecutar fine-tuning:"
    echo "      cd ../../03_FineTuning_Scripts"
    echo "      python3 train_lora.py --config configs/lora_config.yaml"
    echo ""
    echo "   3. Evaluar modelo:"
    echo "      cd ../04_Evaluation"
    echo "      python3 evaluate_model.py --model ../06_Models/lora_adapters/final"
    echo ""
    
    echo "📚 Documentación:"
    echo "   Ver: ../01_Documentacion/00_INICIO_FINE_TUNING.md"
    echo ""
}

################################################################################
# Función Principal
################################################################################

main() {
    print_header "🇲🇽 AztecAI - Instalación Offline de Dependencias"
    
    # Verificaciones
    check_root
    check_prerequisites
    
    # Instalación
    install_system_dependencies
    install_python_dependencies
    
    # Verificación
    if verify_installation; then
        post_install_config
        print_final_info
    else
        print_error "La instalación no se completó correctamente"
        exit 1
    fi
}

# Ejecutar
main "$@"

