# 📦 Instrucciones para Preparar Paquete Offline

**Versión:** 1.0.0  
**Audiencia:** Ingenieros de sistemas  
**Tiempo estimado:** 2-3 horas (dependiendo de conexión)  
**Última actualización:** Enero 2026  

---

## ⚠️ IMPORTANTE

Este documento describe cómo preparar el paquete completo de AztecAI Fine-Tuning para instalación offline. **Estos pasos deben ejecutarse en un servidor CON acceso a internet**, antes de transferir al servidor aislado de producción.

---

## 📋 Tabla de Contenidos

1. [Requisitos Previos](#requisitos)
2. [Descarga del Modelo Base](#modelo)
3. [Descarga de Dependencias Python](#dependencias)
4. [Empaquetado Final](#empaquetado)
5. [Transferencia al Servidor Aislado](#transferencia)
6. [Verificación](#verificacion)

---

<a id="requisitos"></a>
## 1. Requisitos Previos

### Servidor de Preparación (CON Internet)

- **Sistema Operativo:** Ubuntu 22.04 LTS (preferiblemente)
- **Python:** 3.10 o superior
- **Espacio en disco:** 100 GB libres
- **Conexión a internet:** Estable y rápida
- **Herramientas:** git, curl, wget, pip3

### Verificación

```bash
# Sistema operativo
lsb_release -a

# Python
python3 --version

# Espacio en disco
df -h

# Herramientas
which git curl wget pip3
```

---

<a id="modelo"></a>
## 2. Descarga del Modelo Base

### Opción 1: Modelo desde Ollama (Recomendado)

```bash
# Instalar Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Descargar modelo gpt-oss:20b
ollama pull gpt-oss:20b

# Verificar descarga
ollama list | grep gpt-oss

# Localizar archivos del modelo
find ~/.ollama -name "*.gguf" | grep gpt-oss
```

**Ubicación típica:**
```
~/.ollama/models/blobs/sha256-[hash]
```

### Opción 2: Modelo en Formato HuggingFace

**⚠️ Nota:** El modelo gpt-oss:20b puede no estar disponible directamente en HuggingFace. Buscar modelo equivalente o usar conversión desde GGUF.

```bash
# Instalar Git LFS
git lfs install

# Crear directorio para modelos
mkdir -p /opt/models
cd /opt/models

# Descargar modelo (ejemplo con modelo similar)
# Reemplazar con el modelo correcto
git clone https://huggingface.co/[modelo-equivalente]

# Renombrar
mv [modelo-descargado] gpt-oss-20b-hf

# Verificar archivos
ls -lh gpt-oss-20b-hf/
# Debe contener: config.json, pytorch_model.bin, tokenizer.json, etc.
```

### Conversión GGUF a HuggingFace (Avanzado)

```bash
# Clonar llama.cpp
cd /opt
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make

# Localizar modelo GGUF
GGUF_PATH=$(find ~/.ollama -name "*.gguf" | grep gpt-oss | head -1)
echo "Modelo GGUF: $GGUF_PATH"

# Convertir a HuggingFace
# Nota: Este proceso puede variar según el modelo
# Consultar documentación de llama.cpp para detalles específicos
python3 convert.py $GGUF_PATH --outtype f16 --outfile /opt/models/gpt-oss-20b-hf
```

---

<a id="dependencias"></a>
## 3. Descarga de Dependencias Python

### 3.1 Preparar Entorno

```bash
# Navegar al directorio de dependencias
cd /opt/AztecAI_FineTuning/05_Dependencies

# Crear directorio para wheels
mkdir -p python_packages

# Actualizar pip
pip3 install --upgrade pip
```

### 3.2 Descargar Dependencias

```bash
# Descargar todas las dependencias y sus subdependencias
pip3 download -r requirements.txt -d python_packages/

# Esto descargará ~150 archivos .whl (~5 GB)
# Tiempo estimado: 30-60 minutos dependiendo de la conexión
```

**Salida esperada:**
```
Collecting torch==2.1.2
  Downloading torch-2.1.2-cp310-cp310-linux_x86_64.whl (755 MB)
Collecting transformers==4.36.2
  Downloading transformers-4.36.2-py3-none-any.whl (8.2 MB)
...
Successfully downloaded torch transformers peft ... [~150 packages]
```

### 3.3 Verificar Descarga

```bash
# Contar archivos descargados
ls -1 python_packages/*.whl | wc -l
# Debe mostrar ~100-150

# Verificar tamaño total
du -sh python_packages/
# Debe mostrar ~4-6 GB

# Listar paquetes críticos
ls python_packages/ | grep -E "torch|transformers|peft|datasets"
```

### 3.4 Descargar Dependencias Adicionales (Opcional)

```bash
# Si necesitas herramientas adicionales para desarrollo
pip3 download jupyter ipython notebook -d python_packages/

# Si necesitas herramientas de visualización
pip3 download tensorboard wandb -d python_packages/
```

---

<a id="empaquetado"></a>
## 4. Empaquetado Final

### 4.1 Organizar Archivos

```bash
# Estructura final debe ser:
cd /opt/AztecAI_FineTuning

tree -L 2
# AztecAI_FineTuning/
# ├── 01_Documentacion/
# ├── 02_Datasets/
# ├── 03_FineTuning_Scripts/
# ├── 04_Evaluation/
# ├── 05_Dependencies/
# │   ├── python_packages/  ← Con ~150 .whl
# │   ├── requirements.txt
# │   └── install_offline.sh
# ├── 06_Models/
# ├── 07_Validation/
# └── 08_Deployment/
```

### 4.2 Copiar Modelo Base

```bash
# Copiar modelo HuggingFace al paquete
mkdir -p /opt/AztecAI_FineTuning/06_Models/base_model
cp -r /opt/models/gpt-oss-20b-hf /opt/AztecAI_FineTuning/06_Models/base_model/

# O crear enlace simbólico (más rápido)
ln -s /opt/models/gpt-oss-20b-hf /opt/AztecAI_FineTuning/06_Models/base_model/gpt-oss-20b-hf
```

### 4.3 Generar Checksums

```bash
cd /opt/AztecAI_FineTuning

# Generar checksums SHA256 para validación
find . -type f -exec sha256sum {} \; > checksums.sha256

# Verificar archivo de checksums
wc -l checksums.sha256
# Debe mostrar varios cientos de líneas
```

### 4.4 Crear Archivo Comprimido

```bash
cd /opt

# Opción 1: Tar.gz (mejor compresión)
tar -czf AztecAI_FineTuning_complete.tar.gz AztecAI_FineTuning/

# Opción 2: Zip (más compatible)
zip -r AztecAI_FineTuning_complete.zip AztecAI_FineTuning/

# Verificar tamaño del paquete
ls -lh AztecAI_FineTuning_complete.tar.gz
# Debe mostrar ~45-50 GB (con modelo base)
```

### 4.5 Crear Paquete Sin Modelo Base (Alternativa)

Si el modelo base ya está en el servidor de producción:

```bash
cd /opt

# Excluir modelo base del paquete
tar -czf AztecAI_FineTuning_lite.tar.gz \
    --exclude='AztecAI_FineTuning/06_Models/base_model/*' \
    AztecAI_FineTuning/

# Verificar tamaño
ls -lh AztecAI_FineTuning_lite.tar.gz
# Debe mostrar ~5-6 GB (sin modelo base)
```

---

<a id="transferencia"></a>
## 5. Transferencia al Servidor Aislado

### Métodos de Transferencia

#### Opción 1: USB/Disco Externo

```bash
# Montar USB
sudo mount /dev/sdb1 /mnt/usb

# Copiar paquete
cp AztecAI_FineTuning_complete.tar.gz /mnt/usb/

# Desmontar
sudo umount /mnt/usb
```

#### Opción 2: SCP (Si hay red interna)

```bash
# Transferir a servidor aislado
scp AztecAI_FineTuning_complete.tar.gz usuario@servidor-aislado:/opt/

# Con barra de progreso
rsync -avz --progress AztecAI_FineTuning_complete.tar.gz usuario@servidor-aislado:/opt/
```

#### Opción 3: Servidor de Archivos Interno

```bash
# Copiar a servidor de archivos
cp AztecAI_FineTuning_complete.tar.gz /mnt/fileserver/

# Desde servidor aislado, montar y copiar
mount //fileserver/share /mnt/share
cp /mnt/share/AztecAI_FineTuning_complete.tar.gz /opt/
```

---

<a id="verificacion"></a>
## 6. Verificación

### En Servidor de Preparación (Antes de Transferir)

```bash
# Verificar integridad del paquete
cd /opt
tar -tzf AztecAI_FineTuning_complete.tar.gz | head -20

# Verificar que contiene todo
tar -tzf AztecAI_FineTuning_complete.tar.gz | grep -E "requirements.txt|train_lora.py|install_offline.sh"
```

### En Servidor Aislado (Después de Transferir)

```bash
# Verificar integridad del archivo
cd /opt
sha256sum AztecAI_FineTuning_complete.tar.gz

# Extraer
tar -xzf AztecAI_FineTuning_complete.tar.gz

# Verificar checksums
cd AztecAI_FineTuning
sha256sum -c checksums.sha256 | grep -v "OK" | head -20
# No debe mostrar errores

# Verificar estructura
tree -L 2

# Verificar dependencias
ls -lh 05_Dependencies/python_packages/ | wc -l
# Debe mostrar ~150 archivos
```

---

## ✅ Checklist Final

### Antes de Transferir

- [ ] Modelo gpt-oss:20b descargado (Ollama o HuggingFace)
- [ ] Dependencias Python descargadas (~150 .whl en python_packages/)
- [ ] Checksums generados (checksums.sha256)
- [ ] Paquete comprimido creado (.tar.gz o .zip)
- [ ] Tamaño del paquete verificado (~45-50 GB con modelo, ~5-6 GB sin modelo)
- [ ] Integridad del paquete verificada

### Después de Transferir

- [ ] Paquete transferido al servidor aislado
- [ ] Paquete extraído correctamente
- [ ] Checksums validados (sin errores)
- [ ] Estructura de directorios correcta
- [ ] Dependencias presentes (python_packages/ con .whl)
- [ ] Modelo base accesible

---

## 📞 Soporte

Si encuentras problemas durante la preparación del paquete:

1. Verificar conexión a internet
2. Verificar espacio en disco
3. Revisar logs de pip: `pip3 download ... --verbose`
4. Consultar documentación de cada herramienta

---

## 🎯 Próximo Paso

Una vez el paquete esté en el servidor aislado:  
**Continuar con:** `01_Documentacion/GUIA_INSTALACION.md`

---

**Última actualización:** Enero 2026

