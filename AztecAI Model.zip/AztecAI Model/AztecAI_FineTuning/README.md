# 🇲🇽 AztecAI Fine-Tuning System - Entorno Offline

**Versión:** 1.0.0  
**Fecha:** Enero 2026  
**CAIO:** Héctor Romero Pico  
**Organización:** TV Azteca / Grupo Salinas  

---

## 📋 Propósito

Este paquete contiene **TODO lo necesario** para realizar fine-tuning local del modelo **gpt-oss:20b** en un entorno completamente offline, sin acceso a internet.

### ¿Qué incluye este sistema?

✅ **Fine-tuning real** usando LoRA/QLoRA (no solo system prompt)  
✅ **Datasets preparados** basados en conocimiento corporativo de TV Azteca  
✅ **Scripts completamente automatizados** para ejecución sin intervención manual  
✅ **Todas las dependencias** empaquetadas para instalación offline  
✅ **Sistema de evaluación** con métricas de calidad  
✅ **Documentación técnica completa** paso a paso  

---

## 🚀 Inicio Rápido

### Para Ejecutivos y Gerentes
📊 **Leer primero:** [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md)
- Beneficios del fine-tuning vs system prompt
- ROI esperado y métricas de mejora
- Roadmap de implementación

### Para Ingenieros de Sistemas
📦 **Leer primero:** [`01_Documentacion/GUIA_INSTALACION.md`](01_Documentacion/GUIA_INSTALACION.md)
- Instalación paso a paso
- Verificación de requisitos
- Troubleshooting

### Para Data Scientists
🔬 **Leer primero:** [`01_Documentacion/00_INICIO_FINE_TUNING.md`](01_Documentacion/00_INICIO_FINE_TUNING.md)
- Teoría de LoRA/QLoRA
- Configuración de hiperparámetros
- Pipeline de entrenamiento

---

## 🏗️ Arquitectura del Sistema

```
AztecAI_FineTuning/
│
├── 01_Documentacion/              # Guías técnicas completas
│   ├── 00_INICIO_FINE_TUNING.md   # ⭐ EMPEZAR AQUÍ
│   ├── REQUISITOS_HARDWARE.md     # Especificaciones técnicas
│   ├── GUIA_INSTALACION.md        # Instalación paso a paso
│   ├── TEORIA_LORA_QLORA.md       # Fundamentos técnicos
│   └── TROUBLESHOOTING.md         # Solución de problemas
│
├── 02_Datasets/                   # Datos de entrenamiento
│   ├── training/                  # Datasets de entrenamiento
│   ├── validation/                # Datasets de validación
│   ├── test/                      # Datasets de prueba
│   └── scripts/                   # Scripts de preparación
│
├── 03_FineTuning_Scripts/         # Scripts de fine-tuning
│   ├── setup_environment.sh       # Configuración inicial
│   ├── train_lora.py              # Script principal LoRA
│   ├── train_qlora.py             # Script principal QLoRA
│   ├── merge_adapters.py          # Fusión de adaptadores
│   └── configs/                   # Configuraciones
│
├── 04_Evaluation/                 # Sistema de evaluación
│   ├── evaluate_model.py          # Evaluación automática
│   ├── benchmark_suite.py         # Suite de benchmarks
│   ├── compare_models.py          # Comparación base vs fine-tuned
│   └── metrics/                   # Métricas y reportes
│
├── 05_Dependencies/               # Dependencias offline
│   ├── python_packages/           # Wheels de Python
│   ├── ollama_tools/              # Herramientas Ollama
│   ├── install_offline.sh         # Instalador offline
│   └── requirements.txt           # Lista de dependencias
│
├── 06_Models/                     # Modelos y adaptadores
│   ├── base_model/                # Modelo base (placeholder)
│   ├── lora_adapters/             # Adaptadores LoRA entrenados
│   ├── merged_models/             # Modelos fusionados
│   └── checkpoints/               # Checkpoints de entrenamiento
│
├── 07_Validation/                 # Tests de validación
│   ├── test_corporate_knowledge.py
│   ├── test_response_quality.py
│   ├── test_safety_guardrails.py
│   └── test_suites/
│
└── 08_Deployment/                 # Despliegue en Ollama
    ├── create_modelfile.py        # Generador de Modelfile
    ├── deploy_to_ollama.sh        # Despliegue automático
    └── rollback.sh                # Rollback a versión anterior
```

---

## 🚀 Inicio Rápido

### Prerrequisitos

- **Sistema Operativo:** Ubuntu 22.04 LTS
- **RAM:** 64 GB mínimo
- **Almacenamiento:** 200 GB libres
- **GPU:** Opcional (NVIDIA con 24GB+ VRAM recomendado)
- **Modelo base:** gpt-oss:20b ya descargado en Ollama

### Instalación en 3 Pasos

```bash
# 1. Extraer el paquete
cd /opt
unzip AztecAI_FineTuning.zip

# 2. Instalar dependencias (offline)
cd AztecAI_FineTuning/05_Dependencies
sudo bash install_offline.sh

# 3. Ejecutar fine-tuning
cd ../03_FineTuning_Scripts
bash run_complete_pipeline.sh
```

---

## 📊 Metodología: LoRA vs QLoRA

### LoRA (Low-Rank Adaptation)
- **Memoria requerida:** ~40-50 GB RAM
- **Velocidad:** Más rápido
- **Calidad:** Excelente
- **Recomendado para:** Servidores con 64GB+ RAM

### QLoRA (Quantized LoRA)
- **Memoria requerida:** ~20-30 GB RAM
- **Velocidad:** Más lento (cuantización)
- **Calidad:** Muy buena
- **Recomendado para:** Recursos limitados

**Este paquete incluye ambas opciones.**

---

## 📈 Proceso de Fine-Tuning

```
1. PREPARACIÓN DE DATOS
   ├── Conversión de Knowledge Base → JSONL
   ├── Generación de ejemplos sintéticos
   ├── Validación de formato
   └── Split: 80% train / 10% val / 10% test

2. FINE-TUNING
   ├── Configuración de hiperparámetros
   ├── Entrenamiento con LoRA/QLoRA
   ├── Monitoreo de métricas
   └── Guardado de checkpoints

3. EVALUACIÓN
   ├── Métricas cuantitativas (perplexity, loss)
   ├── Evaluación cualitativa (respuestas)
   ├── Comparación vs modelo base
   └── Tests de seguridad

4. DESPLIEGUE
   ├── Fusión de adaptadores
   ├── Creación de Modelfile
   ├── Registro en Ollama
   └── Validación final
```

---

## 🎯 Próximos Pasos

1. **Leer:** `01_Documentacion/00_INICIO_FINE_TUNING.md`
2. **Verificar:** Requisitos de hardware
3. **Ejecutar:** Script de instalación offline
4. **Iniciar:** Pipeline de fine-tuning

---

## 📞 Soporte

**Responsable:** Inteligencia Artificial Azteca (IAA)  
**CAIO:** Héctor Romero Pico  
**Documentación completa:** Ver carpeta `01_Documentacion/`

---

**Última actualización:** Enero 2026

