# 📦 Guía de Instalación - Fine-Tuning de AztecAI

**Versión:** 1.0.0  
**Audiencia:** Ingenieros de sistemas  
**Tiempo estimado:** 1-2 horas  
**Última actualización:** Enero 2026  

---

## 📋 Tabla de Contenidos

1. [Preparación del Servidor](#preparacion)
2. [Instalación de Dependencias Offline](#instalacion)
3. [Configuración del Entorno](#configuracion)
4. [Preparación del Modelo Base](#modelo-base)
5. [Verificación de la Instalación](#verificacion)
6. [Troubleshooting](#troubleshooting)

---

<a id="preparacion"></a>
## 1. Preparación del Servidor

### 1.1 Verificar Requisitos

```bash
# Sistema operativo
lsb_release -a
# Debe mostrar: Ubuntu 22.04 LTS

# RAM
free -h
# Debe mostrar: 64 GB total

# Espacio en disco
df -h /opt
# Debe tener al menos 200 GB libres

# Python
python3 --version
# Debe ser 3.10 o superior
```

### 1.2 Extraer el Paquete

```bash
# Copiar el paquete al servidor (antes de aislarlo)
# Usar USB, SCP, o método disponible

# Extraer en /opt
cd /opt
sudo unzip AztecAI_FineTuning.zip

# Verificar extracción
ls -la AztecAI_FineTuning/
```

### 1.3 Configurar Permisos

```bash
cd /opt/AztecAI_FineTuning

# Dar permisos de ejecución a scripts
sudo chmod +x 03_FineTuning_Scripts/*.py
sudo chmod +x 02_Datasets/scripts/*.py
sudo chmod +x 04_Evaluation/*.py
sudo chmod +x 05_Dependencies/*.sh
sudo chmod +x 08_Deployment/*.sh

# Verificar permisos
ls -l 05_Dependencies/install_offline.sh
# Debe mostrar: -rwxr-xr-x
```

---

<a id="instalacion"></a>
## 2. Instalación de Dependencias Offline

### 2.1 Preparación de Dependencias (ANTES de aislar el servidor)

**⚠️ IMPORTANTE:** Este paso debe hacerse ANTES de aislar el servidor de internet.

```bash
# En un servidor CON internet (puede ser otro servidor)
cd /opt/AztecAI_FineTuning/05_Dependencies

# Descargar todas las dependencias Python
pip3 download -r requirements.txt -d python_packages/

# Verificar descarga
ls -lh python_packages/ | wc -l
# Debe mostrar ~100-150 archivos .whl

# Empaquetar todo
cd /opt
tar -czf AztecAI_FineTuning_complete.tar.gz AztecAI_FineTuning/

# Transferir este archivo al servidor aislado
```

### 2.2 Instalación en Servidor Aislado

```bash
# Extraer paquete completo
cd /opt
sudo tar -xzf AztecAI_FineTuning_complete.tar.gz

# Ejecutar instalador offline
cd AztecAI_FineTuning/05_Dependencies
sudo bash install_offline.sh
```

**Salida esperada:**
```
========================================
🇲🇽 AztecAI - Instalación Offline de Dependencias
========================================

✓ Ejecutando como root
✓ Sistema operativo: Ubuntu
✓ Python instalado: 3.10.12
✓ pip3 instalado
✓ Espacio disponible: 250GB

========================================
Instalando Dependencias del Sistema
========================================
✓ Dependencias del sistema instaladas

========================================
Instalando Dependencias Python (Offline)
========================================
ℹ Encontrados 142 paquetes wheel
✓ Dependencias Python instaladas

========================================
Verificando Instalación
========================================
✓ torch (2.1.2)
✓ transformers (4.36.2)
✓ peft (0.7.1)
✓ datasets (2.16.1)
✓ accelerate (0.25.0)
✓ bitsandbytes (0.41.3)
✓ Todas las dependencias críticas están instaladas

========================================
Instalación Completada
========================================
✅ Todas las dependencias han sido instaladas exitosamente
```

---

<a id="configuracion"></a>
## 3. Configuración del Entorno

### 3.1 Variables de Entorno

```bash
# Crear archivo de configuración
cat > ~/.aztecai_env << 'EOF'
# Variables de entorno para AztecAI Fine-Tuning
export AZTECAI_ROOT="/opt/AztecAI_FineTuning"
export PYTHONPATH="$AZTECAI_ROOT:$PYTHONPATH"
export CUDA_VISIBLE_DEVICES=0  # Si tienes GPU
export TOKENIZERS_PARALLELISM=false
EOF

# Cargar variables
source ~/.aztecai_env

# Agregar a .bashrc para persistencia
echo "source ~/.aztecai_env" >> ~/.bashrc
```

### 3.2 Configuración de Memoria

```bash
# Verificar límites de memoria
ulimit -a

# Si es necesario, aumentar límites
sudo bash -c 'cat >> /etc/security/limits.conf << EOF
* soft memlock unlimited
* hard memlock unlimited
* soft nofile 65536
* hard nofile 65536
EOF'
```

### 3.3 Configuración de Swap (Opcional)

**Solo si RAM < 64GB:**

```bash
# Crear archivo swap de 32GB
sudo fallocate -l 32G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Hacer permanente
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

# Verificar
free -h
```

---

<a id="modelo-base"></a>
## 4. Preparación del Modelo Base

### 4.1 Descargar Modelo Base (ANTES de aislar servidor)

**⚠️ CRÍTICO:** Este paso debe hacerse ANTES de aislar el servidor.

```bash
# En servidor CON internet
ollama pull gpt-oss:20b

# Verificar descarga
ollama list | grep gpt-oss
# Debe mostrar: gpt-oss:20b
```

### 4.2 Convertir Modelo GGUF a HuggingFace Format

El modelo en Ollama está en formato GGUF. Para fine-tuning necesitamos formato HuggingFace.

**Opción 1: Usar modelo HuggingFace directamente**

```bash
# Descargar modelo en formato HuggingFace (ANTES de aislar)
# Nota: Esto requiere ~40GB de descarga

cd /opt/models
git lfs install
git clone https://huggingface.co/[modelo-equivalente-a-gpt-oss-20b]

# Renombrar para consistencia
mv [modelo-descargado] gpt-oss-20b-hf
```

**Opción 2: Convertir desde GGUF (Avanzado)**

```bash
# Instalar llama.cpp (ANTES de aislar)
cd /opt
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make

# Localizar modelo GGUF de Ollama
find ~/.ollama -name "*.gguf" | grep gpt-oss

# Convertir GGUF a HuggingFace
# Nota: Este proceso es complejo y puede requerir pasos adicionales
# Consultar documentación de llama.cpp
```

### 4.3 Verificar Modelo Base

```bash
# Verificar que el modelo esté en formato correcto
ls -lh /opt/models/gpt-oss-20b-hf/

# Debe contener:
# - config.json
# - pytorch_model.bin (o model.safetensors)
# - tokenizer.json
# - tokenizer_config.json
```

---

<a id="verificacion"></a>
## 5. Verificación de la Instalación

### 5.1 Script de Verificación Automática

```bash
cd /opt/AztecAI_FineTuning/05_Dependencies

# Crear script de verificación
cat > verify_installation.py << 'EOF'
#!/usr/bin/env python3
import sys

def check_imports():
    packages = [
        'torch',
        'transformers',
        'peft',
        'datasets',
        'accelerate',
        'bitsandbytes',
        'numpy',
        'pandas'
    ]
    
    print("Verificando paquetes Python...")
    all_ok = True
    
    for package in packages:
        try:
            mod = __import__(package)
            version = getattr(mod, '__version__', 'unknown')
            print(f"✓ {package} ({version})")
        except ImportError:
            print(f"✗ {package} NO INSTALADO")
            all_ok = False
    
    return all_ok

def check_cuda():
    import torch
    print("\nVerificando CUDA...")
    if torch.cuda.is_available():
        print(f"✓ CUDA disponible: {torch.cuda.get_device_name(0)}")
        print(f"  VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    else:
        print("⚠ CUDA no disponible (se usará CPU)")

if __name__ == "__main__":
    if check_imports():
        print("\n✅ Todas las dependencias están instaladas")
        check_cuda()
        sys.exit(0)
    else:
        print("\n❌ Faltan dependencias")
        sys.exit(1)
EOF

chmod +x verify_installation.py
python3 verify_installation.py
```

### 5.2 Verificación Manual

```bash
# Test de PyTorch
python3 -c "import torch; print(f'PyTorch: {torch.__version__}')"

# Test de Transformers
python3 -c "import transformers; print(f'Transformers: {transformers.__version__}')"

# Test de PEFT
python3 -c "import peft; print(f'PEFT: {peft.__version__}')"

# Test de carga de modelo (rápido)
python3 << 'EOF'
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained("/opt/models/gpt-oss-20b-hf")
print(f"✓ Tokenizer cargado: {len(tokenizer)} tokens")
EOF
```

---

<a id="troubleshooting"></a>
## 6. Troubleshooting

### Problema: "No module named 'torch'"

**Solución:**
```bash
cd /opt/AztecAI_FineTuning/05_Dependencies
pip3 install --no-index --find-links=python_packages/ torch
```

### Problema: "CUDA out of memory"

**Solución:**
```bash
# Usar QLoRA en lugar de LoRA
cd /opt/AztecAI_FineTuning/03_FineTuning_Scripts
python3 train_qlora.py --config configs/qlora_config.yaml
```

### Problema: "Model not found"

**Solución:**
```bash
# Verificar ruta del modelo
ls -la /opt/models/gpt-oss-20b-hf/

# Actualizar ruta en configuración
nano configs/lora_config.yaml
# Cambiar: model.local_path
```

### Problema: Instalación lenta

**Solución:**
```bash
# Monitorear progreso
watch -n 5 'ps aux | grep python'

# Ver logs
tail -f /var/log/syslog
```

---

## ✅ Checklist Final

Antes de proceder con el fine-tuning:

- [ ] Servidor Ubuntu 22.04 con 64GB RAM
- [ ] Paquete AztecAI_FineTuning extraído en /opt
- [ ] Dependencias del sistema instaladas
- [ ] Dependencias Python instaladas (verificadas)
- [ ] Modelo base gpt-oss:20b en formato HuggingFace
- [ ] Variables de entorno configuradas
- [ ] Permisos de ejecución configurados
- [ ] Script de verificación ejecutado exitosamente

---

## 🎯 Próximo Paso

**Continuar con:** `00_INICIO_FINE_TUNING.md` - Fase 2: Preparación de Datos

---

**Última actualización:** Enero 2026

