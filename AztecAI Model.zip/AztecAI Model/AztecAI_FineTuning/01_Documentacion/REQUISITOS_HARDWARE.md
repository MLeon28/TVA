# 🖥️ Requisitos de Hardware y Software

**Versión:** 1.0.0  
**Última actualización:** Enero 2026  

---

## 📊 Especificaciones del Servidor Actual

### Servidor On-Premise TV Azteca

```
Sistema Operativo: Ubuntu 22.04 LTS
RAM: 64 GB
CPU: [Especificar modelo]
GPU: [Opcional - especificar si disponible]
Almacenamiento: [Especificar capacidad]
Red: Aislado (sin acceso a internet)
```

---

## ✅ Requisitos Mínimos

### Hardware

| Componente | Mínimo | Recomendado | Servidor TV Azteca |
|------------|--------|-------------|-------------------|
| **RAM** | 32 GB | 64 GB | ✅ 64 GB |
| **CPU** | 8 cores | 16+ cores | ⚠️ Verificar |
| **Almacenamiento** | 150 GB libres | 200 GB libres | ⚠️ Verificar |
| **GPU** | Ninguna (CPU-only) | NVIDIA 24GB+ VRAM | ⚠️ Verificar |

### Software

| Componente | Versión Mínima | Versión Recomendada |
|------------|----------------|---------------------|
| **Ubuntu** | 20.04 LTS | 22.04 LTS |
| **Python** | 3.9 | 3.10+ |
| **Ollama** | 0.1.0 | Latest |
| **CUDA** (si GPU) | 11.8 | 12.1+ |
| **Docker** | 20.10 | Latest |

---

## 🔍 Verificación de Requisitos

### Script de Verificación Automática

```bash
cd AztecAI_FineTuning/01_Documentacion
bash check_requirements.sh
```

### Verificación Manual

#### 1. Sistema Operativo

```bash
lsb_release -a
# Debe mostrar: Ubuntu 22.04 LTS
```

#### 2. RAM

```bash
free -h
# Debe mostrar: 64 GB total
```

#### 3. CPU

```bash
lscpu | grep -E "^CPU\(s\)|Model name"
# Verificar número de cores
```

#### 4. Almacenamiento

```bash
df -h /opt
# Debe tener al menos 200 GB libres
```

#### 5. GPU (Opcional)

```bash
nvidia-smi
# Si hay GPU NVIDIA, verificar VRAM disponible
```

#### 6. Python

```bash
python3 --version
# Debe ser 3.10 o superior
```

#### 7. Ollama

```bash
ollama --version
# Verificar que esté instalado
```

#### 8. Modelo Base

```bash
ollama list | grep gpt-oss:20b
# Debe mostrar el modelo descargado
```

---

## 💾 Estimación de Espacio en Disco

### Desglose de Almacenamiento

```
Componente                          Tamaño
─────────────────────────────────────────────
Modelo base (gpt-oss:20b)           ~40 GB
Datasets de entrenamiento           ~2 GB
Dependencias Python                 ~5 GB
Adaptadores LoRA (entrenados)       ~500 MB
Checkpoints de entrenamiento        ~10 GB
Logs y métricas                     ~1 GB
Modelo fusionado final              ~40 GB
Buffer de seguridad                 ~50 GB
─────────────────────────────────────────────
TOTAL REQUERIDO                     ~150 GB
RECOMENDADO                         ~200 GB
```

---

## 🧮 Estimación de Uso de RAM

### Durante Fine-Tuning

#### Opción 1: LoRA (Recomendado para 64GB)

```
Modelo base cargado:                ~25 GB
Gradientes y optimizador:           ~15 GB
Batch de datos:                     ~2 GB
Sistema operativo:                  ~5 GB
Buffer:                             ~10 GB
─────────────────────────────────────────────
TOTAL                               ~57 GB
MARGEN DE SEGURIDAD                 ~7 GB ✅
```

#### Opción 2: QLoRA (Para sistemas con menos RAM)

```
Modelo base cuantizado (4-bit):     ~12 GB
Gradientes y optimizador:           ~8 GB
Batch de datos:                     ~2 GB
Sistema operativo:                  ~5 GB
Buffer:                             ~5 GB
─────────────────────────────────────────────
TOTAL                               ~32 GB
MARGEN DE SEGURIDAD                 ~32 GB ✅✅
```

### Durante Inferencia (Modelo Fine-Tuneado)

```
Modelo fusionado:                   ~25 GB
Context window (8K tokens):         ~2 GB
Sistema operativo:                  ~5 GB
─────────────────────────────────────────────
TOTAL                               ~32 GB
```

---

## ⚡ Estimación de Tiempos

### Con CPU (sin GPU)

| Fase | Tiempo Estimado |
|------|----------------|
| Preparación de datos | 30 min |
| Fine-tuning (3 épocas, 2000 ejemplos) | 6-8 horas |
| Evaluación | 30 min |
| Fusión y despliegue | 30 min |
| **TOTAL** | **8-10 horas** |

### Con GPU (NVIDIA 24GB+ VRAM)

| Fase | Tiempo Estimado |
|------|----------------|
| Preparación de datos | 30 min |
| Fine-tuning (3 épocas, 2000 ejemplos) | 2-3 horas |
| Evaluación | 15 min |
| Fusión y despliegue | 30 min |
| **TOTAL** | **3-4 horas** |

---

## 🔧 Dependencias de Software

### Paquetes del Sistema (Ubuntu)

```bash
# Incluidos en el instalador offline
build-essential
python3-dev
python3-pip
git
curl
wget
```

### Librerías Python

```
# Ver archivo completo: 05_Dependencies/requirements.txt
torch>=2.0.0
transformers>=4.35.0
peft>=0.7.0
bitsandbytes>=0.41.0
accelerate>=0.24.0
datasets>=2.14.0
sentencepiece>=0.1.99
protobuf>=3.20.0
```

**Todas las dependencias están incluidas en `05_Dependencies/python_packages/`**

---

## ⚠️ Consideraciones Importantes

### Entorno Offline

✅ **Incluido en el paquete:**
- Todas las dependencias Python (wheels)
- Scripts de instalación offline
- Documentación completa

❌ **NO incluido (debe estar previamente instalado):**
- Modelo base gpt-oss:20b (debe descargarse antes de aislar el servidor)
- Sistema operativo Ubuntu 22.04
- Ollama (debe instalarse antes de aislar el servidor)

### Recomendaciones

1. **Descargar modelo base ANTES de aislar el servidor:**
   ```bash
   ollama pull gpt-oss:20b
   ```

2. **Verificar espacio en disco regularmente:**
   ```bash
   watch -n 60 df -h /opt
   ```

3. **Monitorear uso de RAM durante entrenamiento:**
   ```bash
   watch -n 5 free -h
   ```

4. **Configurar swap si es necesario:**
   ```bash
   # Solo si RAM < 64GB
   sudo fallocate -l 32G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```

---

## ✅ Checklist de Verificación

Antes de proceder con la instalación:

- [ ] Ubuntu 22.04 LTS instalado
- [ ] 64 GB de RAM disponible
- [ ] 200 GB de espacio libre en `/opt`
- [ ] Python 3.10+ instalado
- [ ] Ollama instalado y funcionando
- [ ] Modelo gpt-oss:20b descargado
- [ ] Permisos de sudo disponibles
- [ ] Servidor aislado (sin internet) confirmado

---

## 🎯 Próximo Paso

Si todos los requisitos están cumplidos, continuar con:  
**`GUIA_INSTALACION.md`** - Instalación de dependencias offline

---

**Última actualización:** Enero 2026

