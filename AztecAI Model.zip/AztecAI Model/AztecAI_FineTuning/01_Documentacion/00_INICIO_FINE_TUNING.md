# 🚀 Guía de Inicio - Fine-Tuning de AztecAI

**Versión:** 1.0.0  
**Audiencia:** Ingenieros de ML/AI  
**Tiempo estimado:** 4-8 horas (dependiendo de hardware)  

---

## 📋 Tabla de Contenidos

1. [Introducción](#introduccion)
2. [¿Por qué Fine-Tuning vs System Prompt?](#por-que)
3. [Arquitectura del Sistema](#arquitectura)
4. [Roadmap de Implementación](#roadmap)
5. [Decisiones Técnicas Clave](#decisiones)

---

<a id="introduccion"></a>
## 1. Introducción

### ¿Qué es este sistema?

Este es un **sistema completo de fine-tuning local** para el modelo **gpt-oss:20b**, diseñado específicamente para:

- ✅ Funcionar **100% offline** (sin acceso a internet)
- ✅ Ejecutarse en el servidor on-premise de TV Azteca (Ubuntu 22.04, 64GB RAM)
- ✅ Implementar **fine-tuning real** usando LoRA/QLoRA
- ✅ Entrenar el modelo con conocimiento corporativo de TV Azteca
- ✅ Ser completamente automatizado (mínima intervención manual)

### ¿Qué NO es este sistema?

❌ No es solo personalización vía Modelfile (system prompt)  
❌ No requiere conexión a internet durante la ejecución  
❌ No necesita GPUs de alta gama (optimizado para CPU/GPU moderada)  
❌ No es un proceso manual complejo  

---

<a id="por-que"></a>
## 2. ¿Por qué Fine-Tuning vs System Prompt?

### Limitaciones del System Prompt (Enfoque Actual)

| Aspecto | System Prompt | Fine-Tuning |
|---------|--------------|-------------|
| **Conocimiento** | Inyectado en cada request | Internalizado en pesos del modelo |
| **Tokens consumidos** | ~2000-3000 tokens por request | ~100-200 tokens |
| **Consistencia** | Puede variar según contexto | Altamente consistente |
| **Latencia** | Mayor (procesa system prompt cada vez) | Menor (conocimiento ya integrado) |
| **Costo computacional** | Alto (repetitivo) | Bajo (una vez entrenado) |
| **Capacidad de seguir instrucciones** | Buena | Excelente |
| **Personalización profunda** | Limitada | Completa |

### Ventajas del Fine-Tuning

1. **Internalización del conocimiento:** El modelo "aprende" la información corporativa
2. **Reducción de tokens:** No necesita system prompt extenso en cada request
3. **Mejor adherencia:** Sigue mejor las políticas y formato corporativo
4. **Optimización de recursos:** Menor uso de RAM/VRAM en inferencia
5. **Respuestas más naturales:** El conocimiento fluye naturalmente, no como "retrieval"

---

<a id="arquitectura"></a>
## 3. Arquitectura del Sistema

### Componentes Principales

```
┌─────────────────────────────────────────────────────────────┐
│                    ENTORNO OFFLINE                          │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  1. PREPARACIÓN DE DATOS                              │  │
│  │     - Knowledge Base → JSONL                          │  │
│  │     - Generación de ejemplos sintéticos               │  │
│  │     - Validación y limpieza                           │  │
│  └───────────────────────────────────────────────────────┘  │
│                           ↓                                 │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  2. FINE-TUNING (LoRA/QLoRA)                          │  │
│  │     - Carga de modelo base (gpt-oss:20b)              │  │
│  │     - Entrenamiento de adaptadores LoRA               │  │
│  │     - Guardado de checkpoints                         │  │
│  └───────────────────────────────────────────────────────┘  │
│                           ↓                                 │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  3. EVALUACIÓN                                        │  │
│  │     - Métricas cuantitativas (loss, perplexity)       │  │
│  │     - Evaluación cualitativa (respuestas)             │  │
│  │     - Comparación vs modelo base                      │  │
│  └───────────────────────────────────────────────────────┘  │
│                           ↓                                 │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  4. DESPLIEGUE EN OLLAMA                              │  │
│  │     - Fusión de adaptadores con modelo base           │  │
│  │     - Creación de Modelfile optimizado                │  │
│  │     - Registro en Ollama                              │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Stack Tecnológico

- **Framework de Fine-Tuning:** Unsloth (optimizado para eficiencia)
- **Método:** LoRA (Low-Rank Adaptation) / QLoRA (Quantized LoRA)
- **Formato de datos:** JSONL (JSON Lines)
- **Motor de inferencia:** Ollama
- **Lenguaje:** Python 3.10+
- **Librerías principales:** transformers, peft, bitsandbytes, datasets

---

<a id="roadmap"></a>
## 4. Roadmap de Implementación

### Fase 1: Preparación (30 min)

```bash
# 1.1 Verificar requisitos
cd AztecAI_FineTuning/01_Documentacion
cat REQUISITOS_HARDWARE.md

# 1.2 Instalar dependencias offline
cd ../05_Dependencies
sudo bash install_offline.sh

# 1.3 Verificar instalación
python3 verify_installation.py
```

### Fase 2: Preparación de Datos (1-2 horas)

```bash
# 2.1 Generar datasets de entrenamiento
cd ../02_Datasets/scripts
python3 prepare_training_data.py

# 2.2 Validar datasets
python3 validate_datasets.py

# 2.3 Revisar estadísticas
python3 dataset_statistics.py
```

### Fase 3: Fine-Tuning (2-4 horas)

```bash
# 3.1 Configurar hiperparámetros
cd ../../03_FineTuning_Scripts
nano configs/lora_config.yaml

# 3.2 Ejecutar fine-tuning (LoRA recomendado para 64GB RAM)
python3 train_lora.py --config configs/lora_config.yaml

# 3.3 Monitorear progreso
tail -f logs/training.log
```

### Fase 4: Evaluación (30 min)

```bash
# 4.1 Evaluar modelo fine-tuneado
cd ../04_Evaluation
python3 evaluate_model.py --model ../06_Models/lora_adapters/final

# 4.2 Comparar con modelo base
python3 compare_models.py

# 4.3 Generar reporte
python3 generate_report.py
```

### Fase 5: Despliegue (30 min)

```bash
# 5.1 Fusionar adaptadores
cd ../03_FineTuning_Scripts
python3 merge_adapters.py

# 5.2 Desplegar en Ollama
cd ../08_Deployment
bash deploy_to_ollama.sh

# 5.3 Validar despliegue
ollama run aztecai-finetuned "¿Qué es TV Azteca?"
```

---

<a id="decisiones"></a>
## 5. Decisiones Técnicas Clave

### ¿LoRA o QLoRA?

**Recomendación para servidor de 64GB RAM: LoRA**

| Criterio | LoRA | QLoRA |
|----------|------|-------|
| RAM requerida | 40-50 GB | 20-30 GB |
| Velocidad | ⚡⚡⚡ Rápido | ⚡⚡ Moderado |
| Calidad | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Uso en servidor 64GB | ✅ Ideal | ⚠️ Sobra capacidad |

### Hiperparámetros Recomendados

```yaml
# Para gpt-oss:20b con 64GB RAM
lora_r: 16                    # Rank de LoRA
lora_alpha: 32                # Scaling factor
lora_dropout: 0.05            # Dropout para regularización
learning_rate: 2e-4           # Learning rate
batch_size: 4                 # Batch size (ajustar según RAM)
gradient_accumulation: 4      # Acumulación de gradientes
epochs: 3                     # Número de épocas
warmup_steps: 100             # Pasos de warmup
```

### Tamaño del Dataset

- **Mínimo:** 500 ejemplos de alta calidad
- **Recomendado:** 1,000-2,000 ejemplos
- **Óptimo:** 3,000-5,000 ejemplos

**Este paquete incluye ~2,500 ejemplos generados del Knowledge Base actual.**

---

## ✅ Checklist Pre-Inicio

Antes de comenzar, verifica:

- [ ] Servidor Ubuntu 22.04 con 64GB RAM
- [ ] Modelo gpt-oss:20b descargado en Ollama
- [ ] 200 GB de espacio libre en disco
- [ ] Permisos de sudo
- [ ] Paquete AztecAI_FineTuning extraído en `/opt/`
- [ ] Documentación leída (este archivo)

---

## 🎯 Próximo Paso

**Leer:** `REQUISITOS_HARDWARE.md` para verificar compatibilidad del servidor.

---

**¿Listo para comenzar?** Continúa con la instalación de dependencias.

