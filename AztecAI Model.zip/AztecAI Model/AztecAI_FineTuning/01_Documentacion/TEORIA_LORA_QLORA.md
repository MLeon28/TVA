# 📚 Fundamentos Técnicos: LoRA y QLoRA

**Versión:** 1.0.0  
**Audiencia:** Ingenieros de ML/AI  
**Última actualización:** Enero 2026  

---

## 📋 Tabla de Contenidos

1. [Introducción](#introduccion)
2. [¿Qué es LoRA?](#lora)
3. [¿Qué es QLoRA?](#qlora)
4. [Comparación LoRA vs QLoRA](#comparacion)
5. [Implementación Técnica](#implementacion)
6. [Hiperparámetros Clave](#hiperparametros)
7. [Mejores Prácticas](#mejores-practicas)

---

<a id="introduccion"></a>
## 1. Introducción

### El Problema del Fine-Tuning Tradicional

El fine-tuning tradicional de modelos grandes (como gpt-oss:20b con ~20 mil millones de parámetros) presenta varios desafíos:

- **Memoria:** Requiere cargar todos los parámetros del modelo en memoria
- **Almacenamiento:** Necesita guardar una copia completa del modelo para cada tarea
- **Costo computacional:** Actualiza todos los parámetros durante el entrenamiento
- **Tiempo:** El entrenamiento es extremadamente lento

### La Solución: Parameter-Efficient Fine-Tuning (PEFT)

LoRA y QLoRA son técnicas de **PEFT** que permiten fine-tuning eficiente:

- ✅ Solo entrenan un pequeño conjunto de parámetros adicionales
- ✅ Mantienen el modelo base congelado
- ✅ Reducen drásticamente el uso de memoria
- ✅ Aceleran el entrenamiento
- ✅ Permiten múltiples adaptaciones del mismo modelo base

---

<a id="lora"></a>
## 2. ¿Qué es LoRA?

### Low-Rank Adaptation (LoRA)

**Paper original:** "LoRA: Low-Rank Adaptation of Large Language Models" (Hu et al., 2021)

### Concepto Fundamental

LoRA se basa en la hipótesis de que los cambios necesarios en los pesos del modelo durante el fine-tuning tienen una **dimensionalidad intrínseca baja**.

### Cómo Funciona

En lugar de actualizar directamente la matriz de pesos `W` del modelo:

```
Modelo tradicional:
W_new = W_original + ΔW

LoRA:
W_new = W_original + B × A

Donde:
- W_original: Matriz de pesos original (congelada)
- B: Matriz de bajo rango (d × r)
- A: Matriz de bajo rango (r × k)
- r: Rank (mucho menor que d y k)
```

### Ventajas de LoRA

1. **Reducción de parámetros entrenables:**
   - Modelo original: 20B parámetros
   - LoRA (r=16): ~10-50M parámetros entrenables (~0.25%)

2. **Reducción de memoria:**
   - Full fine-tuning: ~80 GB RAM
   - LoRA: ~40-50 GB RAM

3. **Velocidad:**
   - 2-3x más rápido que fine-tuning completo

4. **Modularidad:**
   - Múltiples adaptadores LoRA para diferentes tareas
   - Intercambiables sobre el mismo modelo base

### Ejemplo Numérico

Para una capa de atención con dimensión 4096:

```
Matriz original W: 4096 × 4096 = 16,777,216 parámetros

LoRA con r=16:
- Matriz A: 4096 × 16 = 65,536 parámetros
- Matriz B: 16 × 4096 = 65,536 parámetros
- Total LoRA: 131,072 parámetros

Reducción: 99.2% menos parámetros
```

---

<a id="qlora"></a>
## 3. ¿Qué es QLoRA?

### Quantized Low-Rank Adaptation (QLoRA)

**Paper original:** "QLoRA: Efficient Finetuning of Quantized LLMs" (Dettmers et al., 2023)

### Concepto Fundamental

QLoRA combina **cuantización** con **LoRA** para reducir aún más el uso de memoria.

### Innovaciones Clave

1. **4-bit NormalFloat (NF4):**
   - Cuantización de 4 bits optimizada para pesos de redes neuronales
   - Preserva mejor la distribución de pesos que int4 estándar

2. **Double Quantization:**
   - Cuantiza también las constantes de cuantización
   - Ahorro adicional de memoria

3. **Paged Optimizers:**
   - Usa memoria paginada para evitar OOM (Out of Memory)
   - Permite entrenar modelos más grandes

### Cómo Funciona

```
QLoRA Pipeline:
1. Cargar modelo base en 4-bit (NF4)
2. Agregar adaptadores LoRA en fp16/bf16
3. Entrenar solo los adaptadores LoRA
4. Gradientes se calculan en fp16/bf16
5. Modelo base permanece en 4-bit
```

### Ventajas de QLoRA

1. **Reducción extrema de memoria:**
   - Full fine-tuning: ~80 GB RAM
   - LoRA: ~40-50 GB RAM
   - QLoRA: ~20-30 GB RAM

2. **Calidad comparable:**
   - Resultados muy cercanos a LoRA completo
   - Pérdida mínima de precisión

3. **Accesibilidad:**
   - Permite fine-tuning en hardware consumer
   - GPUs de 24GB pueden entrenar modelos de 65B parámetros

---

<a id="comparacion"></a>
## 4. Comparación LoRA vs QLoRA

### Tabla Comparativa

| Aspecto | Full Fine-Tuning | LoRA | QLoRA |
|---------|------------------|------|-------|
| **Parámetros entrenables** | 100% | 0.1-1% | 0.1-1% |
| **Memoria (20B modelo)** | ~80 GB | ~40-50 GB | ~20-30 GB |
| **Velocidad** | 1x (baseline) | 2-3x | 1.5-2x |
| **Calidad** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Almacenamiento** | ~40 GB | ~500 MB | ~500 MB |
| **GPU requerida** | A100 80GB | A100 40GB | RTX 3090 24GB |
| **Complejidad** | Baja | Media | Alta |

### ¿Cuándo usar cada uno?

#### Usar LoRA cuando:
- ✅ Tienes 64GB+ RAM
- ✅ Quieres máxima calidad
- ✅ Velocidad es importante
- ✅ Tienes GPU con 40GB+ VRAM

#### Usar QLoRA cuando:
- ✅ Memoria limitada (<64GB RAM)
- ✅ GPU con 24GB VRAM
- ✅ Calidad ligeramente menor es aceptable
- ✅ Quieres experimentar rápidamente

---

<a id="implementacion"></a>
## 5. Implementación Técnica

### Arquitectura de LoRA en el Código

```python
from peft import LoraConfig, get_peft_model

# Configuración de LoRA
lora_config = LoraConfig(
    r=16,                          # Rank
    lora_alpha=32,                 # Scaling factor
    target_modules=[               # Módulos a adaptar
        "q_proj",
        "v_proj",
        "k_proj",
        "o_proj"
    ],
    lora_dropout=0.05,             # Dropout
    bias="none",                   # No entrenar bias
    task_type="CAUSAL_LM"          # Tipo de tarea
)

# Aplicar LoRA al modelo
model = get_peft_model(base_model, lora_config)

# Ver parámetros entrenables
model.print_trainable_parameters()
# Output: trainable params: 10M || all params: 20B || trainable%: 0.05%
```

### Arquitectura de QLoRA en el Código

```python
from transformers import BitsAndBytesConfig
from peft import prepare_model_for_kbit_training

# Configuración de cuantización 4-bit
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)

# Cargar modelo en 4-bit
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    quantization_config=bnb_config,
    device_map="auto"
)

# Preparar para entrenamiento
model = prepare_model_for_kbit_training(model)

# Aplicar LoRA
model = get_peft_model(model, lora_config)
```

---

<a id="hiperparametros"></a>
## 6. Hiperparámetros Clave

### Rank (r)

**Definición:** Dimensión de las matrices de bajo rango.

**Valores típicos:** 4, 8, 16, 32, 64

**Impacto:**
- ↑ Mayor rank → Mayor capacidad de aprendizaje
- ↑ Mayor rank → Más parámetros entrenables
- ↑ Mayor rank → Más memoria requerida

**Recomendación para AztecAI:**
```yaml
r: 16  # Balance óptimo para 64GB RAM
```

### Alpha (α)

**Definición:** Factor de escalado para las actualizaciones de LoRA.

**Fórmula:** `scaling = alpha / r`

**Valores típicos:** 2x el rank (si r=16, entonces α=32)

**Recomendación para AztecAI:**
```yaml
lora_alpha: 32  # 2x el rank
```

### Target Modules

**Definición:** Capas del modelo donde se aplica LoRA.

**Opciones comunes:**
- `q_proj, v_proj`: Solo atención (mínimo)
- `q_proj, v_proj, k_proj, o_proj`: Atención completa (recomendado)
- `q_proj, v_proj, k_proj, o_proj, gate_proj, up_proj, down_proj`: Atención + FFN (máximo)

**Recomendación para AztecAI:**
```yaml
target_modules: ["q_proj", "v_proj", "k_proj", "o_proj"]
```

---

<a id="mejores-practicas"></a>
## 7. Mejores Prácticas

### Para Servidor de 64GB RAM (AztecAI)

1. **Usar LoRA (no QLoRA):**
   - Tienes suficiente RAM
   - Mejor calidad
   - Más rápido

2. **Configuración recomendada:**
   ```yaml
   r: 16
   alpha: 32
   dropout: 0.05
   batch_size: 4
   gradient_accumulation: 4
   ```

3. **Monitoreo:**
   - Vigilar uso de RAM: `watch -n 5 free -h`
   - Logs de entrenamiento: `tail -f logs/training.log`

4. **Checkpoints:**
   - Guardar cada 200 steps
   - Mantener últimos 3 checkpoints

5. **Evaluación:**
   - Evaluar cada 100 steps
   - Comparar con modelo base

---

## 📚 Referencias

1. Hu et al. (2021) - "LoRA: Low-Rank Adaptation of Large Language Models"
2. Dettmers et al. (2023) - "QLoRA: Efficient Finetuning of Quantized LLMs"
3. HuggingFace PEFT Documentation
4. Unsloth Optimization Library

---

**Última actualización:** Enero 2026

