#!/usr/bin/env python3
"""
Script de Fine-Tuning con LoRA para AztecAI
Entrena el modelo gpt-oss:20b con conocimiento corporativo de TV Azteca

Autor: Inteligencia Artificial Azteca (IAA)
Versión: 1.0.0
Fecha: Enero 2026
"""

import os
import sys
import torch
import yaml
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional

# Importaciones de librerías de ML
try:
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        TrainingArguments,
        Trainer,
        DataCollatorForLanguageModeling
    )
    from peft import (
        LoraConfig,
        get_peft_model,
        prepare_model_for_kbit_training,
        TaskType
    )
    from datasets import load_dataset
except ImportError as e:
    print(f"❌ Error: Falta instalar dependencias: {e}")
    print("Ejecuta: cd ../05_Dependencies && bash install_offline.sh")
    sys.exit(1)


class AztecAIFineTuner:
    """Clase principal para fine-tuning de AztecAI con LoRA"""
    
    def __init__(self, config_path: str):
        """
        Inicializa el fine-tuner
        
        Args:
            config_path: Ruta al archivo de configuración YAML
        """
        self.config = self._load_config(config_path)
        self.model = None
        self.tokenizer = None
        self.train_dataset = None
        self.val_dataset = None
        
        # Configurar directorios
        self.output_dir = Path(self.config['output']['model_dir'])
        self.log_dir = Path(self.config['output']['log_dir'])
        self.checkpoint_dir = Path(self.config['output']['checkpoint_dir'])
        
        # Crear directorios
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        print("✅ AztecAI Fine-Tuner inicializado")
    
    def _load_config(self, config_path: str) -> Dict:
        """Carga la configuración desde archivo YAML"""
        print(f"📖 Cargando configuración desde: {config_path}")
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        print("✅ Configuración cargada")
        return config
    
    def load_model_and_tokenizer(self):
        """Carga el modelo base y el tokenizer"""
        print("\n" + "="*70)
        print("📥 CARGANDO MODELO BASE Y TOKENIZER")
        print("="*70)
        
        model_name = self.config['model']['base_model']
        print(f"Modelo: {model_name}")
        
        # Cargar tokenizer
        print("Cargando tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True
        )
        
        # Configurar padding token si no existe
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        print("✅ Tokenizer cargado")
        
        # Cargar modelo
        print("Cargando modelo base (esto puede tomar varios minutos)...")
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        
        print("✅ Modelo base cargado")
        print(f"Parámetros del modelo: {self.model.num_parameters():,}")
    
    def configure_lora(self):
        """Configura LoRA para el modelo"""
        print("\n" + "="*70)
        print("⚙️  CONFIGURANDO LoRA")
        print("="*70)
        
        lora_config = LoraConfig(
            r=self.config['lora']['rank'],
            lora_alpha=self.config['lora']['alpha'],
            target_modules=self.config['lora']['target_modules'],
            lora_dropout=self.config['lora']['dropout'],
            bias="none",
            task_type=TaskType.CAUSAL_LM
        )
        
        print(f"LoRA Rank: {lora_config.r}")
        print(f"LoRA Alpha: {lora_config.lora_alpha}")
        print(f"Target Modules: {lora_config.target_modules}")
        print(f"Dropout: {lora_config.lora_dropout}")
        
        # Preparar modelo para entrenamiento
        self.model = prepare_model_for_kbit_training(self.model)
        
        # Aplicar LoRA
        self.model = get_peft_model(self.model, lora_config)
        
        # Mostrar parámetros entrenables
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())
        
        print(f"\n📊 Parámetros:")
        print(f"   Total: {total_params:,}")
        print(f"   Entrenables: {trainable_params:,}")
        print(f"   Porcentaje entrenable: {100 * trainable_params / total_params:.2f}%")
        print("✅ LoRA configurado")
    
    def load_datasets(self):
        """Carga los datasets de entrenamiento y validación"""
        print("\n" + "="*70)
        print("📚 CARGANDO DATASETS")
        print("="*70)
        
        train_path = self.config['data']['train_file']
        val_path = self.config['data']['val_file']
        
        print(f"Dataset de entrenamiento: {train_path}")
        print(f"Dataset de validación: {val_path}")
        
        # Cargar datasets
        self.train_dataset = load_dataset('json', data_files=train_path, split='train')
        self.val_dataset = load_dataset('json', data_files=val_path, split='train')
        
        print(f"✅ Ejemplos de entrenamiento: {len(self.train_dataset)}")
        print(f"✅ Ejemplos de validación: {len(self.val_dataset)}")
        
        # Tokenizar datasets
        print("Tokenizando datasets...")
        self.train_dataset = self.train_dataset.map(
            self._tokenize_function,
            batched=True,
            remove_columns=self.train_dataset.column_names
        )
        self.val_dataset = self.val_dataset.map(
            self._tokenize_function,
            batched=True,
            remove_columns=self.val_dataset.column_names
        )
        print("✅ Datasets tokenizados")
    
    def _tokenize_function(self, examples):
        """Función de tokenización para los ejemplos"""
        # Combinar instruction, input y output
        texts = []
        for i in range(len(examples['instruction'])):
            instruction = examples['instruction'][i]
            input_text = examples.get('input', [''])[i]
            output = examples['output'][i]
            
            if input_text:
                text = f"### Instrucción:\n{instruction}\n\n### Entrada:\n{input_text}\n\n### Respuesta:\n{output}"
            else:
                text = f"### Instrucción:\n{instruction}\n\n### Respuesta:\n{output}"
            
            texts.append(text)
        
        # Tokenizar
        return self.tokenizer(
            texts,
            truncation=True,
            max_length=self.config['training']['max_length'],
            padding='max_length'
        )
    
    def train(self):
        """Ejecuta el entrenamiento"""
        print("\n" + "="*70)
        print("🚀 INICIANDO ENTRENAMIENTO")
        print("="*70)
        
        # Configurar argumentos de entrenamiento
        training_args = TrainingArguments(
            output_dir=str(self.checkpoint_dir),
            num_train_epochs=self.config['training']['epochs'],
            per_device_train_batch_size=self.config['training']['batch_size'],
            per_device_eval_batch_size=self.config['training']['batch_size'],
            gradient_accumulation_steps=self.config['training']['gradient_accumulation_steps'],
            learning_rate=self.config['training']['learning_rate'],
            warmup_steps=self.config['training']['warmup_steps'],
            logging_dir=str(self.log_dir),
            logging_steps=self.config['training']['logging_steps'],
            save_steps=self.config['training']['save_steps'],
            eval_steps=self.config['training']['eval_steps'],
            evaluation_strategy="steps",
            save_total_limit=3,
            load_best_model_at_end=True,
            fp16=True,
            report_to="none"
        )
        
        # Crear trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=self.train_dataset,
            eval_dataset=self.val_dataset,
            data_collator=DataCollatorForLanguageModeling(self.tokenizer, mlm=False)
        )
        
        # Entrenar
        print(f"\n⏱️  Iniciando entrenamiento - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        trainer.train()
        
        print(f"\n✅ Entrenamiento completado - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Guardar modelo final
        print(f"\n💾 Guardando modelo en: {self.output_dir}")
        trainer.save_model(str(self.output_dir))
        self.tokenizer.save_pretrained(str(self.output_dir))
        print("✅ Modelo guardado")


def main():
    """Función principal"""
    parser = argparse.ArgumentParser(description="Fine-tuning de AztecAI con LoRA")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/lora_config.yaml",
        help="Ruta al archivo de configuración"
    )
    args = parser.parse_args()
    
    print("="*70)
    print("🇲🇽 AztecAI - Fine-Tuning con LoRA")
    print("="*70)
    print()
    
    # Inicializar fine-tuner
    finetuner = AztecAIFineTuner(args.config)
    
    # Ejecutar pipeline
    finetuner.load_model_and_tokenizer()
    finetuner.configure_lora()
    finetuner.load_datasets()
    finetuner.train()
    
    print("\n" + "="*70)
    print("✅ PROCESO COMPLETADO EXITOSAMENTE")
    print("="*70)


if __name__ == "__main__":
    main()

