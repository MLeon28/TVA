#!/usr/bin/env python3
"""
Script de Fusión de Adaptadores LoRA con Modelo Base
Combina los adaptadores LoRA entrenados con el modelo base para crear un modelo unificado

Autor: Inteligencia Artificial Azteca (IAA)
Versión: 1.0.0
Fecha: Enero 2026
"""

import os
import sys
import argparse
from pathlib import Path
from datetime import datetime

try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
except ImportError as e:
    print(f"❌ Error: Falta instalar dependencias: {e}")
    sys.exit(1)


class AdapterMerger:
    """Clase para fusionar adaptadores LoRA con modelo base"""
    
    def __init__(self, base_model_path: str, adapter_path: str, output_path: str):
        """
        Inicializa el merger
        
        Args:
            base_model_path: Ruta al modelo base
            adapter_path: Ruta a los adaptadores LoRA
            output_path: Ruta donde guardar el modelo fusionado
        """
        self.base_model_path = base_model_path
        self.adapter_path = adapter_path
        self.output_path = Path(output_path)
        
        self.base_model = None
        self.merged_model = None
        self.tokenizer = None
    
    def load_models(self):
        """Carga el modelo base y los adaptadores"""
        print("\n" + "="*70)
        print("📥 CARGANDO MODELO BASE Y ADAPTADORES")
        print("="*70)
        
        # Cargar tokenizer
        print("\nCargando tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.base_model_path,
            trust_remote_code=True
        )
        print("✅ Tokenizer cargado")
        
        # Cargar modelo base
        print("\nCargando modelo base...")
        print(f"Ruta: {self.base_model_path}")
        self.base_model = AutoModelForCausalLM.from_pretrained(
            self.base_model_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        print("✅ Modelo base cargado")
        print(f"Parámetros: {self.base_model.num_parameters():,}")
        
        # Cargar adaptadores LoRA
        print("\nCargando adaptadores LoRA...")
        print(f"Ruta: {self.adapter_path}")
        self.merged_model = PeftModel.from_pretrained(
            self.base_model,
            self.adapter_path
        )
        print("✅ Adaptadores LoRA cargados")
    
    def merge(self):
        """Fusiona los adaptadores con el modelo base"""
        print("\n" + "="*70)
        print("🔄 FUSIONANDO ADAPTADORES CON MODELO BASE")
        print("="*70)
        
        print("\nIniciando fusión...")
        print("⚠️  Este proceso puede tomar varios minutos...")
        
        # Fusionar adaptadores
        self.merged_model = self.merged_model.merge_and_unload()
        
        print("✅ Adaptadores fusionados exitosamente")
        print(f"Parámetros del modelo fusionado: {self.merged_model.num_parameters():,}")
    
    def save_merged_model(self):
        """Guarda el modelo fusionado"""
        print("\n" + "="*70)
        print("💾 GUARDANDO MODELO FUSIONADO")
        print("="*70)
        
        # Crear directorio de salida
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        print(f"\nGuardando modelo en: {self.output_path}")
        print("⚠️  Este proceso puede tomar varios minutos...")
        
        # Guardar modelo
        self.merged_model.save_pretrained(
            str(self.output_path),
            safe_serialization=True
        )
        
        # Guardar tokenizer
        self.tokenizer.save_pretrained(str(self.output_path))
        
        print("✅ Modelo fusionado guardado exitosamente")
        
        # Mostrar información del modelo guardado
        self._print_model_info()
    
    def _print_model_info(self):
        """Imprime información sobre el modelo guardado"""
        print("\n" + "="*70)
        print("📊 INFORMACIÓN DEL MODELO FUSIONADO")
        print("="*70)
        
        # Calcular tamaño del modelo
        total_size = 0
        for file in self.output_path.rglob('*'):
            if file.is_file():
                total_size += file.stat().st_size
        
        size_gb = total_size / (1024**3)
        
        print(f"\n📁 Ubicación: {self.output_path}")
        print(f"💾 Tamaño: {size_gb:.2f} GB")
        print(f"🔢 Parámetros: {self.merged_model.num_parameters():,}")
        print(f"📅 Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Listar archivos principales
        print("\n📄 Archivos principales:")
        for file in sorted(self.output_path.glob('*')):
            if file.is_file():
                size_mb = file.stat().st_size / (1024**2)
                print(f"   - {file.name} ({size_mb:.1f} MB)")
    
    def verify_model(self):
        """Verifica que el modelo fusionado funcione correctamente"""
        print("\n" + "="*70)
        print("✅ VERIFICANDO MODELO FUSIONADO")
        print("="*70)
        
        print("\nEjecutando test de generación...")
        
        # Test simple
        test_prompt = "### Instrucción:\n¿Qué es TV Azteca?\n\n### Respuesta:\n"
        
        inputs = self.tokenizer(
            test_prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        ).to(self.merged_model.device)
        
        with torch.no_grad():
            outputs = self.merged_model.generate(
                **inputs,
                max_new_tokens=200,
                temperature=0.7,
                top_p=0.9,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id
            )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        print("\n" + "-"*70)
        print("Prompt de prueba:")
        print(test_prompt)
        print("\nRespuesta generada:")
        print(response)
        print("-"*70)
        
        print("\n✅ Modelo fusionado funciona correctamente")
    
    def run(self):
        """Ejecuta el proceso completo de fusión"""
        self.load_models()
        self.merge()
        self.save_merged_model()
        self.verify_model()


def main():
    """Función principal"""
    parser = argparse.ArgumentParser(
        description="Fusión de adaptadores LoRA con modelo base"
    )
    parser.add_argument(
        "--base_model",
        type=str,
        default="/opt/models/gpt-oss-20b-hf",
        help="Ruta al modelo base en formato HuggingFace"
    )
    parser.add_argument(
        "--adapter",
        type=str,
        default="../06_Models/lora_adapters/aztecai_lora_final",
        help="Ruta a los adaptadores LoRA entrenados"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="../06_Models/merged_models/aztecai_merged",
        help="Ruta donde guardar el modelo fusionado"
    )
    args = parser.parse_args()
    
    print("="*70)
    print("🇲🇽 AztecAI - Fusión de Adaptadores LoRA")
    print("="*70)
    print()
    
    # Verificar que existan las rutas
    if not os.path.exists(args.base_model):
        print(f"❌ Error: Modelo base no encontrado en {args.base_model}")
        print("\nNota: El modelo debe estar en formato HuggingFace, no GGUF")
        print("Si tienes el modelo en Ollama (GGUF), necesitas convertirlo primero.")
        sys.exit(1)
    
    if not os.path.exists(args.adapter):
        print(f"❌ Error: Adaptadores LoRA no encontrados en {args.adapter}")
        print("\nEjecuta primero el entrenamiento:")
        print("  python3 train_lora.py --config configs/lora_config.yaml")
        sys.exit(1)
    
    # Ejecutar fusión
    merger = AdapterMerger(args.base_model, args.adapter, args.output)
    merger.run()
    
    print("\n" + "="*70)
    print("✅ FUSIÓN COMPLETADA EXITOSAMENTE")
    print("="*70)
    print()
    print("🎯 Próximos pasos:")
    print("   1. Desplegar en Ollama:")
    print("      cd ../08_Deployment")
    print("      bash deploy_to_ollama.sh")
    print()
    print("   2. O usar directamente con transformers:")
    print(f"      model = AutoModelForCausalLM.from_pretrained('{args.output}')")
    print()


if __name__ == "__main__":
    main()

