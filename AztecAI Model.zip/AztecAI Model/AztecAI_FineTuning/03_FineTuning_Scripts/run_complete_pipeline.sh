#!/bin/bash
################################################################################
# Pipeline Completo de Fine-Tuning para AztecAI
# 
# Autor: Inteligencia Artificial Azteca (IAA)
# Versión: 1.0.0
# Fecha: Enero 2026
#
# Descripción:
#   Ejecuta el pipeline completo de fine-tuning de forma automatizada:
#   1. Preparación de datos
#   2. Fine-tuning con LoRA
#   3. Evaluación del modelo
#   4. Fusión de adaptadores
#   5. Despliegue en Ollama
#
# Uso:
#   bash run_complete_pipeline.sh [--skip-data-prep] [--skip-training] [--skip-eval]
################################################################################

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuración
SKIP_DATA_PREP=false
SKIP_TRAINING=false
SKIP_EVAL=false
SKIP_DEPLOYMENT=false

# Directorios
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
DATA_SCRIPTS_DIR="$PROJECT_ROOT/02_Datasets/scripts"
EVAL_DIR="$PROJECT_ROOT/04_Evaluation"
DEPLOYMENT_DIR="$PROJECT_ROOT/08_Deployment"
LOGS_DIR="$PROJECT_ROOT/06_Models/logs"

# Archivos de log
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
MAIN_LOG="$LOGS_DIR/pipeline_${TIMESTAMP}.log"

################################################################################
# Funciones de Utilidad
################################################################################

print_header() {
    echo -e "\n${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║ $1${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}\n"
}

print_step() {
    echo -e "\n${BLUE}▶ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$MAIN_LOG"
}

################################################################################
# Parseo de Argumentos
################################################################################

parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --skip-data-prep)
                SKIP_DATA_PREP=true
                shift
                ;;
            --skip-training)
                SKIP_TRAINING=true
                shift
                ;;
            --skip-eval)
                SKIP_EVAL=true
                shift
                ;;
            --skip-deployment)
                SKIP_DEPLOYMENT=true
                shift
                ;;
            *)
                echo "Argumento desconocido: $1"
                echo "Uso: $0 [--skip-data-prep] [--skip-training] [--skip-eval] [--skip-deployment]"
                exit 1
                ;;
        esac
    done
}

################################################################################
# Verificaciones Iniciales
################################################################################

check_prerequisites() {
    print_header "VERIFICANDO PRERREQUISITOS"
    
    # Verificar Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 no está instalado"
        exit 1
    fi
    print_success "Python 3 instalado"
    
    # Verificar dependencias Python
    print_step "Verificando dependencias Python..."
    python3 -c "import torch, transformers, peft, datasets" 2>/dev/null
    if [ $? -eq 0 ]; then
        print_success "Dependencias Python instaladas"
    else
        print_error "Faltan dependencias Python"
        print_info "Ejecuta: cd ../05_Dependencies && bash install_offline.sh"
        exit 1
    fi
    
    # Verificar Ollama
    if ! command -v ollama &> /dev/null; then
        print_warning "Ollama no está instalado (necesario para despliegue)"
    else
        print_success "Ollama instalado"
    fi
    
    # Crear directorios de logs
    mkdir -p "$LOGS_DIR"
    
    log_message "Prerrequisitos verificados"
}

################################################################################
# Fase 1: Preparación de Datos
################################################################################

prepare_data() {
    if [ "$SKIP_DATA_PREP" = true ]; then
        print_warning "Saltando preparación de datos (--skip-data-prep)"
        return
    fi
    
    print_header "FASE 1: PREPARACIÓN DE DATOS"
    log_message "Iniciando preparación de datos"
    
    cd "$DATA_SCRIPTS_DIR"
    
    print_step "Generando datasets de entrenamiento..."
    python3 prepare_training_data.py 2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Datasets generados exitosamente"
        log_message "Datasets generados exitosamente"
    else
        print_error "Error en la generación de datasets"
        log_message "ERROR: Fallo en generación de datasets"
        exit 1
    fi
    
    print_step "Validando datasets..."
    python3 validate_datasets.py 2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Datasets validados"
        log_message "Datasets validados"
    else
        print_error "Error en la validación de datasets"
        log_message "ERROR: Fallo en validación de datasets"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
}

################################################################################
# Fase 2: Fine-Tuning
################################################################################

run_finetuning() {
    if [ "$SKIP_TRAINING" = true ]; then
        print_warning "Saltando entrenamiento (--skip-training)"
        return
    fi
    
    print_header "FASE 2: FINE-TUNING CON LoRA"
    log_message "Iniciando fine-tuning"
    
    print_step "Ejecutando entrenamiento..."
    print_info "Esto puede tomar varias horas dependiendo del hardware"
    print_info "Logs en tiempo real: tail -f $LOGS_DIR/training.log"
    
    python3 train_lora.py --config configs/lora_config.yaml 2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Fine-tuning completado exitosamente"
        log_message "Fine-tuning completado exitosamente"
    else
        print_error "Error durante el fine-tuning"
        log_message "ERROR: Fallo en fine-tuning"
        exit 1
    fi
}

################################################################################
# Fase 3: Evaluación
################################################################################

run_evaluation() {
    if [ "$SKIP_EVAL" = true ]; then
        print_warning "Saltando evaluación (--skip-eval)"
        return
    fi
    
    print_header "FASE 3: EVALUACIÓN DEL MODELO"
    log_message "Iniciando evaluación"
    
    cd "$EVAL_DIR"
    
    print_step "Evaluando modelo fine-tuneado..."
    python3 evaluate_model.py \
        --base_model "/opt/models/gpt-oss-20b-hf" \
        --finetuned_model "../06_Models/lora_adapters/aztecai_lora_final" \
        --test_data "../02_Datasets/test/aztecai_test.jsonl" \
        --output "metrics" \
        2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Evaluación completada"
        log_message "Evaluación completada"
    else
        print_error "Error durante la evaluación"
        log_message "ERROR: Fallo en evaluación"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
}

################################################################################
# Fase 4: Fusión de Adaptadores
################################################################################

merge_adapters() {
    print_header "FASE 4: FUSIÓN DE ADAPTADORES"
    log_message "Iniciando fusión de adaptadores"
    
    print_step "Fusionando adaptadores LoRA con modelo base..."
    python3 merge_adapters.py 2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Adaptadores fusionados exitosamente"
        log_message "Adaptadores fusionados exitosamente"
    else
        print_error "Error durante la fusión"
        log_message "ERROR: Fallo en fusión de adaptadores"
        exit 1
    fi
}

################################################################################
# Fase 5: Despliegue
################################################################################

deploy_model() {
    if [ "$SKIP_DEPLOYMENT" = true ]; then
        print_warning "Saltando despliegue (--skip-deployment)"
        return
    fi
    
    print_header "FASE 5: DESPLIEGUE EN OLLAMA"
    log_message "Iniciando despliegue"
    
    cd "$DEPLOYMENT_DIR"
    
    print_step "Desplegando modelo en Ollama..."
    bash deploy_to_ollama.sh 2>&1 | tee -a "$MAIN_LOG"
    
    if [ $? -eq 0 ]; then
        print_success "Modelo desplegado exitosamente"
        log_message "Modelo desplegado exitosamente"
    else
        print_error "Error durante el despliegue"
        log_message "ERROR: Fallo en despliegue"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
}

################################################################################
# Resumen Final
################################################################################

print_summary() {
    print_header "RESUMEN DEL PIPELINE"
    
    echo -e "${GREEN}✅ Pipeline completado exitosamente${NC}\n"
    
    echo "📊 Fases ejecutadas:"
    [ "$SKIP_DATA_PREP" = false ] && echo "   ✓ Preparación de datos"
    [ "$SKIP_TRAINING" = false ] && echo "   ✓ Fine-tuning con LoRA"
    [ "$SKIP_EVAL" = false ] && echo "   ✓ Evaluación del modelo"
    echo "   ✓ Fusión de adaptadores"
    [ "$SKIP_DEPLOYMENT" = false ] && echo "   ✓ Despliegue en Ollama"
    echo ""
    
    echo "📁 Archivos generados:"
    echo "   - Datasets: $PROJECT_ROOT/02_Datasets/"
    echo "   - Modelo LoRA: $PROJECT_ROOT/06_Models/lora_adapters/"
    echo "   - Modelo fusionado: $PROJECT_ROOT/06_Models/merged_models/"
    echo "   - Métricas: $PROJECT_ROOT/04_Evaluation/metrics/"
    echo "   - Logs: $MAIN_LOG"
    echo ""
    
    echo "🚀 Uso del modelo:"
    echo "   ollama run aztecai-finetuned"
    echo ""
    
    echo "⏱️  Tiempo total: $(date -d@$SECONDS -u +%H:%M:%S)"
    echo ""
    
    log_message "Pipeline completado exitosamente"
}

################################################################################
# Main
################################################################################

main() {
    # Banner
    echo -e "${CYAN}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                                                                ║"
    echo "║        🇲🇽  AztecAI Fine-Tuning Pipeline Automatizado         ║"
    echo "║                                                                ║"
    echo "║              TV Azteca / Grupo Salinas                         ║"
    echo "║                                                                ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}\n"
    
    # Parsear argumentos
    parse_arguments "$@"
    
    # Iniciar timer
    SECONDS=0
    
    # Ejecutar pipeline
    check_prerequisites
    prepare_data
    run_finetuning
    run_evaluation
    merge_adapters
    deploy_model
    
    # Resumen
    print_summary
}

main "$@"

