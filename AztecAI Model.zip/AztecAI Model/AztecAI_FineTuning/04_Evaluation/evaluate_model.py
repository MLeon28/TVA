#!/usr/bin/env python3
"""
Script de Evaluación para Modelo Fine-Tuneado de AztecAI
Compara el rendimiento del modelo fine-tuneado vs modelo base

Autor: Inteligencia Artificial Azteca (IAA)
Versión: 1.0.0
Fecha: Enero 2026
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import List, Dict, Tuple
from datetime import datetime
import numpy as np

try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
    from datasets import load_dataset
    from tqdm import tqdm
except ImportError as e:
    print(f"❌ Error: Falta instalar dependencias: {e}")
    sys.exit(1)


class ModelEvaluator:
    """Evaluador de modelos fine-tuneados"""
    
    def __init__(self, base_model_path: str, finetuned_model_path: str, test_data_path: str):
        """
        Inicializa el evaluador
        
        Args:
            base_model_path: Ruta al modelo base
            finetuned_model_path: Ruta al modelo fine-tuneado (adaptadores LoRA)
            test_data_path: Ruta al dataset de test
        """
        self.base_model_path = base_model_path
        self.finetuned_model_path = finetuned_model_path
        self.test_data_path = test_data_path
        
        self.base_model = None
        self.finetuned_model = None
        self.tokenizer = None
        self.test_dataset = None
        
        self.results = {
            'base_model': {},
            'finetuned_model': {},
            'comparison': {}
        }
    
    def load_models(self):
        """Carga el modelo base y el modelo fine-tuneado"""
        print("\n" + "="*70)
        print("📥 CARGANDO MODELOS")
        print("="*70)
        
        # Cargar tokenizer
        print("Cargando tokenizer...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.base_model_path,
            trust_remote_code=True
        )
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        print("✅ Tokenizer cargado")
        
        # Cargar modelo base
        print("\nCargando modelo base...")
        self.base_model = AutoModelForCausalLM.from_pretrained(
            self.base_model_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        print("✅ Modelo base cargado")
        
        # Cargar modelo fine-tuneado (con adaptadores LoRA)
        print("\nCargando modelo fine-tuneado...")
        self.finetuned_model = AutoModelForCausalLM.from_pretrained(
            self.base_model_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True
        )
        self.finetuned_model = PeftModel.from_pretrained(
            self.finetuned_model,
            self.finetuned_model_path
        )
        print("✅ Modelo fine-tuneado cargado")
    
    def load_test_data(self):
        """Carga el dataset de test"""
        print("\n" + "="*70)
        print("📚 CARGANDO DATASET DE TEST")
        print("="*70)
        
        self.test_dataset = load_dataset('json', data_files=self.test_data_path, split='train')
        print(f"✅ {len(self.test_dataset)} ejemplos de test cargados")
    
    def evaluate_perplexity(self, model, dataset, model_name: str) -> float:
        """
        Calcula la perplejidad del modelo en el dataset
        
        Args:
            model: Modelo a evaluar
            dataset: Dataset de evaluación
            model_name: Nombre del modelo (para logging)
        
        Returns:
            Perplejidad promedio
        """
        print(f"\n📊 Calculando perplejidad para {model_name}...")
        
        model.eval()
        total_loss = 0
        total_tokens = 0
        
        with torch.no_grad():
            for example in tqdm(dataset, desc=f"Evaluando {model_name}"):
                # Preparar texto
                instruction = example['instruction']
                output = example['output']
                text = f"### Instrucción:\n{instruction}\n\n### Respuesta:\n{output}"
                
                # Tokenizar
                inputs = self.tokenizer(
                    text,
                    return_tensors="pt",
                    truncation=True,
                    max_length=2048
                ).to(model.device)
                
                # Calcular loss
                outputs = model(**inputs, labels=inputs['input_ids'])
                loss = outputs.loss
                
                total_loss += loss.item() * inputs['input_ids'].size(1)
                total_tokens += inputs['input_ids'].size(1)
        
        # Calcular perplejidad
        avg_loss = total_loss / total_tokens
        perplexity = np.exp(avg_loss)
        
        print(f"✅ Perplejidad de {model_name}: {perplexity:.2f}")
        return perplexity
    
    def evaluate_response_quality(self, model, examples: List[Dict], model_name: str) -> Dict:
        """
        Evalúa la calidad de las respuestas generadas
        
        Args:
            model: Modelo a evaluar
            examples: Lista de ejemplos de test
            model_name: Nombre del modelo
        
        Returns:
            Diccionario con métricas de calidad
        """
        print(f"\n📝 Evaluando calidad de respuestas para {model_name}...")
        
        model.eval()
        responses = []
        
        with torch.no_grad():
            for example in tqdm(examples[:20], desc=f"Generando respuestas - {model_name}"):
                instruction = example['instruction']
                prompt = f"### Instrucción:\n{instruction}\n\n### Respuesta:\n"
                
                inputs = self.tokenizer(
                    prompt,
                    return_tensors="pt",
                    truncation=True,
                    max_length=512
                ).to(model.device)
                
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=512,
                    temperature=0.7,
                    top_p=0.9,
                    do_sample=True,
                    pad_token_id=self.tokenizer.pad_token_id
                )
                
                response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                responses.append({
                    'instruction': instruction,
                    'response': response,
                    'expected': example['output']
                })
        
        # Calcular métricas de calidad
        metrics = self._calculate_quality_metrics(responses)
        
        print(f"✅ Evaluación de calidad completada para {model_name}")
        return metrics
    
    def _calculate_quality_metrics(self, responses: List[Dict]) -> Dict:
        """Calcula métricas de calidad de las respuestas"""
        metrics = {
            'avg_length': np.mean([len(r['response']) for r in responses]),
            'contains_header': sum(1 for r in responses if '🇲🇽 AztecAI' in r['response']) / len(responses),
            'contains_separator': sum(1 for r in responses if '━━━' in r['response']) / len(responses),
            'contains_next_step': sum(1 for r in responses if '🎯' in r['response']) / len(responses),
            'total_responses': len(responses)
        }
        return metrics
    
    def compare_models(self):
        """Compara los resultados de ambos modelos"""
        print("\n" + "="*70)
        print("📊 COMPARACIÓN DE MODELOS")
        print("="*70)
        
        base_perp = self.results['base_model']['perplexity']
        ft_perp = self.results['finetuned_model']['perplexity']
        
        improvement = ((base_perp - ft_perp) / base_perp) * 100
        
        print(f"\n📈 Perplejidad:")
        print(f"   Modelo Base:        {base_perp:.2f}")
        print(f"   Modelo Fine-Tuned:  {ft_perp:.2f}")
        print(f"   Mejora:             {improvement:.2f}%")
        
        print(f"\n📝 Calidad de Respuestas (Modelo Fine-Tuned):")
        quality = self.results['finetuned_model']['quality']
        print(f"   Longitud promedio:  {quality['avg_length']:.0f} caracteres")
        print(f"   Incluye header:     {quality['contains_header']*100:.0f}%")
        print(f"   Incluye separador:  {quality['contains_separator']*100:.0f}%")
        print(f"   Incluye next step:  {quality['contains_next_step']*100:.0f}%")
        
        self.results['comparison'] = {
            'perplexity_improvement': improvement,
            'base_perplexity': base_perp,
            'finetuned_perplexity': ft_perp
        }
    
    def save_results(self, output_path: str):
        """Guarda los resultados de la evaluación"""
        print(f"\n💾 Guardando resultados en: {output_path}")
        
        output_file = Path(output_path) / f"evaluation_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Resultados guardados en: {output_file}")
    
    def run_evaluation(self):
        """Ejecuta la evaluación completa"""
        # Evaluar modelo base
        print("\n" + "="*70)
        print("🔍 EVALUANDO MODELO BASE")
        print("="*70)
        base_perp = self.evaluate_perplexity(self.base_model, self.test_dataset, "Modelo Base")
        self.results['base_model']['perplexity'] = base_perp
        
        # Evaluar modelo fine-tuneado
        print("\n" + "="*70)
        print("🔍 EVALUANDO MODELO FINE-TUNEADO")
        print("="*70)
        ft_perp = self.evaluate_perplexity(self.finetuned_model, self.test_dataset, "Modelo Fine-Tuned")
        self.results['finetuned_model']['perplexity'] = ft_perp
        
        # Evaluar calidad de respuestas
        ft_quality = self.evaluate_response_quality(
            self.finetuned_model,
            list(self.test_dataset),
            "Modelo Fine-Tuned"
        )
        self.results['finetuned_model']['quality'] = ft_quality
        
        # Comparar modelos
        self.compare_models()


def main():
    parser = argparse.ArgumentParser(description="Evaluación de modelo fine-tuneado de AztecAI")
    parser.add_argument("--base_model", type=str, required=True, help="Ruta al modelo base")
    parser.add_argument("--finetuned_model", type=str, required=True, help="Ruta a adaptadores LoRA")
    parser.add_argument("--test_data", type=str, required=True, help="Ruta al dataset de test")
    parser.add_argument("--output", type=str, default="metrics", help="Directorio de salida")
    args = parser.parse_args()
    
    print("="*70)
    print("🇲🇽 AztecAI - Evaluación de Modelo Fine-Tuneado")
    print("="*70)
    
    evaluator = ModelEvaluator(args.base_model, args.finetuned_model, args.test_data)
    evaluator.load_models()
    evaluator.load_test_data()
    evaluator.run_evaluation()
    evaluator.save_results(args.output)
    
    print("\n" + "="*70)
    print("✅ EVALUACIÓN COMPLETADA")
    print("="*70)


if __name__ == "__main__":
    main()

