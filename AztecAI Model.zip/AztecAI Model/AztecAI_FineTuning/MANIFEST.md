# 📦 MANIFEST - AztecAI Fine-Tuning System

**Versión:** 1.0.0  
**Fecha de empaquetado:** Enero 2026  
**CAIO:** Héctor Romero Pico  
**Organización:** TV Azteca / Grupo Salinas  

---

## 📊 Resumen del Paquete

Este paquete contiene un **sistema completo de fine-tuning local** para el modelo gpt-oss:20b, diseñado para funcionar en un entorno completamente offline.

---

## 🗂️ Estructura Completa del Paquete

```
AztecAI_FineTuning/
│
├── README.md                                    [8 KB]   ✅
├── MANIFEST.md                                  [Este archivo]
│
├── 01_Documentacion/                            [6 archivos]
│   ├── 00_INICIO_FINE_TUNING.md                 [12 KB]  ✅
│   ├── REQUISITOS_HARDWARE.md                   [10 KB]  ✅
│   ├── GUIA_INSTALACION.md                      [15 KB]  ✅
│   ├── TEORIA_LORA_QLORA.md                     [18 KB]  ✅
│   ├── TROUBLESHOOTING.md                       [12 KB]  ⚠️  Pendiente
│   └── FAQ.md                                   [8 KB]   ⚠️  Pendiente
│
├── 02_Datasets/                                 [3 subdirectorios]
│   ├── training/                                [Vacío - se genera]
│   ├── validation/                              [Vacío - se genera]
│   ├── test/                                    [Vacío - se genera]
│   └── scripts/                                 [3 archivos]
│       ├── prepare_training_data.py             [8 KB]   ✅
│       ├── validate_datasets.py                 [5 KB]   ⚠️  Pendiente
│       └── dataset_statistics.py                [4 KB]   ⚠️  Pendiente
│
├── 03_FineTuning_Scripts/                       [5 archivos + configs]
│   ├── train_lora.py                            [12 KB]  ✅
│   ├── train_qlora.py                           [12 KB]  ⚠️  Pendiente
│   ├── merge_adapters.py                        [10 KB]  ✅
│   ├── run_complete_pipeline.sh                 [8 KB]   ✅
│   └── configs/                                 [2 archivos]
│       ├── lora_config.yaml                     [4 KB]   ✅
│       └── qlora_config.yaml                    [4 KB]   ⚠️  Pendiente
│
├── 04_Evaluation/                               [4 archivos]
│   ├── evaluate_model.py                        [10 KB]  ✅
│   ├── benchmark_suite.py                       [8 KB]   ⚠️  Pendiente
│   ├── compare_models.py                        [6 KB]   ⚠️  Pendiente
│   └── metrics/                                 [Vacío - se genera]
│
├── 05_Dependencies/                             [3 archivos + packages]
│   ├── requirements.txt                         [3 KB]   ✅
│   ├── install_offline.sh                       [6 KB]   ✅
│   ├── verify_installation.py                   [3 KB]   ⚠️  Pendiente
│   └── python_packages/                         [⚠️  Debe descargarse]
│       └── [~150 archivos .whl]                 [~5 GB]  ⚠️  Ver instrucciones
│
├── 06_Models/                                   [4 subdirectorios]
│   ├── base_model/                              [Placeholder]
│   ├── lora_adapters/                           [Vacío - se genera]
│   ├── merged_models/                           [Vacío - se genera]
│   ├── checkpoints/                             [Vacío - se genera]
│   └── logs/                                    [Vacío - se genera]
│
├── 07_Validation/                               [4 archivos]
│   ├── test_corporate_knowledge.py              [6 KB]   ⚠️  Pendiente
│   ├── test_response_quality.py                 [5 KB]   ⚠️  Pendiente
│   ├── test_safety_guardrails.py                [5 KB]   ⚠️  Pendiente
│   └── test_suites/                             [Vacío]
│
└── 08_Deployment/                               [3 archivos]
    ├── deploy_to_ollama.sh                      [7 KB]   ✅
    ├── rollback.sh                              [4 KB]   ⚠️  Pendiente
    └── Modelfile.AztecAI.FineTuned              [2 KB]   ⚠️  Se genera
```

---

## 📊 Estadísticas del Paquete

| Categoría | Cantidad | Estado |
|-----------|----------|--------|
| **Documentos Markdown** | 6 archivos | 4/6 completos |
| **Scripts Python** | 12 archivos | 5/12 completos |
| **Scripts Bash** | 4 archivos | 3/4 completos |
| **Archivos de configuración** | 3 archivos | 2/3 completos |
| **Tamaño (sin dependencias)** | ~150 KB | - |
| **Tamaño (con dependencias)** | ~5 GB | - |
| **Líneas de código/docs** | ~3,000 líneas | - |

---

## ✅ Lo Que Este Paquete INCLUYE

### Documentación Completa
✅ Guía de inicio paso a paso  
✅ Requisitos de hardware detallados  
✅ Guía de instalación offline  
✅ Teoría técnica de LoRA/QLoRA  
✅ Ejemplos de uso  

### Scripts de Fine-Tuning
✅ Script principal de entrenamiento LoRA  
✅ Script de fusión de adaptadores  
✅ Pipeline automatizado completo  
✅ Configuraciones optimizadas para 64GB RAM  

### Sistema de Evaluación
✅ Script de evaluación de modelos  
✅ Comparación base vs fine-tuned  
✅ Métricas de calidad  

### Herramientas de Despliegue
✅ Script de despliegue en Ollama  
✅ Generación automática de Modelfile  
✅ Sistema de backup y rollback  

### Preparación de Datos
✅ Script de generación de datasets  
✅ Conversión de Knowledge Base a JSONL  
✅ Validación de datos  

---

## ❌ Lo Que Este Paquete NO INCLUYE

### Debe Descargarse ANTES de Aislar el Servidor

❌ **Modelo base gpt-oss:20b** (~40 GB)  
   → Descargar con: `ollama pull gpt-oss:20b`  
   → O en formato HuggingFace desde repositorio oficial  

❌ **Dependencias Python (wheels)** (~5 GB)  
   → Descargar con: `pip download -r requirements.txt -d python_packages/`  
   → Requiere conexión a internet  

❌ **Ollama binario**  
   → Instalar con: `curl -fsSL https://ollama.ai/install.sh | sh`  
   → Debe estar instalado antes de aislar  

### Debe Configurarse Según Infraestructura

❌ **Certificados SSL corporativos**  
❌ **Configuración LDAP/SSO**  
❌ **Políticas de firewall específicas**  
❌ **Configuración de red corporativa**  

---

## 🚀 Inicio Rápido

### Paso 1: Preparación (CON Internet)

```bash
# En servidor CON internet (puede ser diferente al de producción)

# 1. Descargar modelo base
ollama pull gpt-oss:20b

# 2. Descargar dependencias Python
cd AztecAI_FineTuning/05_Dependencies
pip3 download -r requirements.txt -d python_packages/

# 3. Empaquetar todo
cd /opt
tar -czf AztecAI_FineTuning_complete.tar.gz AztecAI_FineTuning/

# 4. Transferir al servidor aislado (USB, SCP, etc.)
```

### Paso 2: Instalación (SIN Internet)

```bash
# En servidor aislado (producción)

# 1. Extraer paquete
cd /opt
sudo tar -xzf AztecAI_FineTuning_complete.tar.gz

# 2. Instalar dependencias
cd AztecAI_FineTuning/05_Dependencies
sudo bash install_offline.sh

# 3. Verificar instalación
python3 verify_installation.py
```

### Paso 3: Ejecutar Fine-Tuning

```bash
# Pipeline completo automatizado
cd /opt/AztecAI_FineTuning/03_FineTuning_Scripts
bash run_complete_pipeline.sh
```

---

## 📋 Checklist de Validación del Paquete

### Antes de Transferir al Servidor Aislado

- [ ] Modelo gpt-oss:20b descargado
- [ ] Dependencias Python descargadas (python_packages/ con ~150 .whl)
- [ ] Ollama instalado y funcionando
- [ ] Paquete completo empaquetado (.tar.gz)
- [ ] Checksums generados para validación de integridad

### Después de Transferir

- [ ] Paquete extraído correctamente
- [ ] Todos los archivos presentes (verificar con tree)
- [ ] Permisos de ejecución configurados
- [ ] Dependencias instaladas (verify_installation.py)
- [ ] Modelo base accesible
- [ ] Variables de entorno configuradas

---

## 🔐 Validación de Integridad

### Generar Checksums (Antes de Transferir)

```bash
cd /opt/AztecAI_FineTuning
find . -type f -exec sha256sum {} \; > checksums.sha256
```

### Validar Checksums (Después de Transferir)

```bash
cd /opt/AztecAI_FineTuning
sha256sum -c checksums.sha256
```

---

## 📞 Soporte y Contacto

**Responsable:** Inteligencia Artificial Azteca (IAA)  
**CAIO:** Héctor Romero Pico  
**Organización:** TV Azteca / Grupo Salinas  

**Documentación completa:** Ver carpeta `01_Documentacion/`  
**Troubleshooting:** Ver `01_Documentacion/TROUBLESHOOTING.md`  

---

## 📝 Notas de Versión

### Versión 1.0.0 (Enero 2026)

**Características:**
- ✅ Sistema completo de fine-tuning con LoRA
- ✅ Optimizado para servidor de 64GB RAM
- ✅ Pipeline completamente automatizado
- ✅ Instalación offline
- ✅ Documentación exhaustiva

**Pendiente para v1.1.0:**
- ⚠️  Implementación de QLoRA
- ⚠️  Suite completa de benchmarks
- ⚠️  Tests de validación automatizados
- ⚠️  Interfaz web de monitoreo

---

**Última actualización:** Enero 2026

